//
//  CustomAnnotation.swift
//  BasicMapView
//
//  Created by Chaithanya Krishna  on 2/27/18.
//  Copyright © 2018 Chaithanya Krishna. All rights reserved.
/**Purpose:The purpose of this class is to create a custom attributes for our location in the map.
This class helps to store the attributes of map like location with latitude and longitude,title and subtitle**/


//Importing the libraries required
import UIKit
//Importing the Map Kit for our map
import MapKit

//Defining the class Custom annotation ,this extends MKAnnotation which is required for Map.
//MKAnnotation is added as header to CustomAnnotation Class
class CustomAnnotation: NSObject,MKAnnotation  {

    //Declaring the varibales required for our map
    //Cordinate is of type locationCordinate and title and subtitle are the strings
    var coordinate: CLLocationCoordinate2D
    var title:String?
    var subtitle:String?
//Defining the initialisation method.
    //This method takes 3 parameters.One is of type locationcordinate and the other two are strings.
    //The purpose of this function is to initialize the variables of custom annotation class.
    init(coordinate: CLLocationCoordinate2D,title: String,subtitle:String)
    {
        //initialising the parameters of the function to variables of custom annotation class
        self.coordinate=coordinate
        self.title=title
        self.subtitle=subtitle
    }
    
 }
