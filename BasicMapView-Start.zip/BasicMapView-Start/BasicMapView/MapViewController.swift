//
//  MapViewController.swift
//  BasicMapView
//
//  Created by Chaithanya Krishna  on 2/27/18.
//  Copyright © 2018 Chaithanya Krishna. All rights reserved.

/****
 ZID:Z1815642
 SPRING 2018
 IOS 521
 Chaithanya krishna Gogineni
 ****/
/*The purpose of this class :This acts as a controller for our map view .
 This class sets the variables required for the map and sends them to custom annotation (MODEL).
 This is of type UIView Controller and MKMapViewDelegate is added as header notation*/

/**********************
 Question:What would happen if you do not include the mapTypeSegment IBOutlet?
 In the current assignment,We dont need to include mapTypeSegment IB outlet as we used UISegmented control action
 But if we dont have action for UIsegment control,then this outlet helps to get the selected variable either it is standard or satellite or hybrid.
 We must use mayTypeSegment (OUTLET of UISegmentControl),when we dont have action.
 
 *********/


//Importing the libraries required
import UIKit
//Importing the MapKit library to work with Map
import MapKit

//defining the MapViewController class.It defines all the variables required and communicates with model(Custom Annotation)

class MapViewController: UIViewController , MKMapViewDelegate{

    //referencing the IBoutlet of map view. of type MKMapView
    @IBOutlet weak var mapView: MKMapView!
    //referencing the IBoutlet of mapTypeSegment of type UISegmented Control
    @IBOutlet weak var mapTypeSegment: UISegmentedControl!
    
    //referencing the IBaction.
    @IBAction func mapTypeControl(_ sender: UISegmentedControl) {
        
        //Initialising a segment variable
        
        let segIndex = sender.selectedSegmentIndex
        //switch to appropriate view if we click on hybrid,satellite or standard.
        switch segIndex{
        case 0:
            mapView.mapType = .standard
        case 1:
            mapView.mapType = .satellite
        case 2:
            mapView.mapType = .hybrid
        default:
            break
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Initialsing the variables
        //set the location .set latitude and longitude
        let myLocCoordinate = CLLocationCoordinate2D(latitude: 37.774929,longitude: -122.419416)
        //sending the data values to custom annotation
        
        let annotationPin = CustomAnnotation(coordinate: myLocCoordinate, title: "San Fransisco", subtitle: "Beautiful place in california")
        
        //setting the constraints for the map
        let mapRegion = MKCoordinateRegionMakeWithDistance(myLocCoordinate,500,500)
        //setting the map region
        mapView.setRegion(mapRegion, animated:true)
        //Adding the current annotation to map
        mapView.addAnnotation(annotationPin as MKAnnotation)
        // Do any additional setup after loading the view.
    }


}
