//
//  AboutAppViewController.swift
//  CGogiTopTenMendoza
//
//  Created by Chaithanya Krishna Gogineni on 3/7/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
/*
 This is IOS 521 MID Term Application
 Author :Chaithanya Krishna
 ZID:Z1815642
 MID TERM
 IOS 521  SPRING 2018
 DUE:03-08-2018
 Instructor:Kaisone Rush
 */

//Importing the libraries required
import UIKit
import MessageUI

//The purpose of this class is it acts as a view controller for About app view
class AboutAppViewController: UIViewController,MFMailComposeViewControllerDelegate {

    //Implementing the function viewDidLoad()
    override func viewDidLoad() {
        super.viewDidLoad()
    //settimng the title of the screen
        navigationItem.title = "About App"

        // Do any additional setup after loading the view.
    }

    //referening the IB action for the feedback button
    //By clicking on this button,we can email feedback of our app to others
    @IBAction func sendEmailButton(_ sender: UIButton) {
        
        //Initialising the variables
     
        let mailComposeVC = MFMailComposeViewController()
        
        mailComposeVC.mailComposeDelegate = self
        
        //setting the variables
        let toRecipients = ["niucsci@gmail.com"]
        let emailTitle = "Midterm Exam App Feedback"
        let messageBody = "Feedback for Midterm Exam App, Version 1.0"
        
        //Calling the functions that helps to send the required receipents
        mailComposeVC.setToRecipients(toRecipients)
        //Function that helps to set the title of the email
        mailComposeVC.setSubject(emailTitle)
        //Setting the Mesage Body
        mailComposeVC.setMessageBody(messageBody, isHTML: false)
        
        self.present(mailComposeVC, animated: true, completion: nil)
       
    }
    // This function displays the message string on the console
    // so that I can test to make sure if the email message was
    // cancelled, failed, saved draft or sent.
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        
        switch result.rawValue {
            
        case MFMailComposeResult.cancelled.rawValue:
            print("cancelled")
            
        case MFMailComposeResult.failed.rawValue:
            print("failed")
            
        case MFMailComposeResult.saved.rawValue:
            print("saved")
            
        case MFMailComposeResult.sent.rawValue:
            print("sent")
            
        default:
            break
            
        }
        
        // Dismiss the compose view controller after the ComposeVC
        // finishes.
        self.dismiss(animated: true, completion: nil)
        
    }
    
    
    
    //Referencing the About Author button
    //By clicking on this button ,user can navigate to AuthorViewController
    
    @IBAction func aboutAuthor(_ sender: UIButton) {
        //Setting the storyboard variable
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        //setting the destnation controller
        let destinationVC = storyboard.instantiateViewController(withIdentifier: "AuthorViewController") as! AboutAuthorViewController
        //calling the View controller on new navigation controller
        self.navigationController?.pushViewController(destinationVC, animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
