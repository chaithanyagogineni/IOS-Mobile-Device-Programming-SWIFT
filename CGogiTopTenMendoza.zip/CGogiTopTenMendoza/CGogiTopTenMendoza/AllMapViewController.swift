//
//  AllMapViewController.swift
//  CGogiTopTenMendoza
//
//  Created by Chaithanya Krishna Gogineni on 3/8/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
/*
 This is IOS 521 MID Term Application
 Author :Chaithanya Krishna
 ZID:Z1815642
 MID TERM
 IOS 521  SPRING 2018
 DUE:03-08-2018
 Instructor:Kaisone Rush
 */
//This if for the extra credit
//We can see all the locations by zooming out
//importing the libraries required
import UIKit
import MapKit

//The purpose of this class is to display all the locations of hotels ,attractions and restaurants
class AllMapViewController: UIViewController , MKMapViewDelegate {
   
    //declaring AllCustomAnnotation object
    var custAnnotation = [AllCustomAnnotation]()
    
    //Declaring the variables required
    var hotel_name : String!
    var hotel_subtitle :String!
    var hotel_latitude : String!
    var hotel_longitude : String!
    
    var res_name : String!
    var res_rating : String!
    var res_latitude : String!
    var res_longitude : String!
    
    var attr_name : String!
    var attr_subtitle : String!
    var attr_latitude : String!
    var attr_longitude : String!
    
    //referencing the mapview outlet
    @IBOutlet weak var mapView: MKMapView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Ready title,subtitle and latitude and longitude
        //Reading data from hotels Property list
        //get the path
        let path = Bundle.main.path(forResource: "HotelsList", ofType: "plist")!
        //read the array
        let hotelArray:NSArray = NSArray(contentsOfFile:path)!
        
        //for each item in array ,since each item is dictionary get all the attributes and store in local varaibles.
        for item in hotelArray {
            
            let dictionary: [String: String] = (item as? Dictionary)!
             hotel_name = dictionary["Name"]
             hotel_subtitle = dictionary["Subtitle"]
             hotel_latitude = dictionary["Latitude"]
             hotel_longitude = dictionary["Longitude"]
            //setting the cordinates of the map
            let myLocCoordinate = CLLocationCoordinate2D(latitude: Double(hotel_latitude)!,longitude: Double(hotel_longitude)!)
            //Calling the Allcustomannotation constructor with map cordinates and title and subtitle
            let annotationPin = AllCustomAnnotation(coordinate: myLocCoordinate, title: hotel_name, subtitle: hotel_subtitle)
            
            //setting the constraints for the map
            let mapRegion = MKCoordinateRegionMakeWithDistance(myLocCoordinate,1000,1000)
            //setting the map region
           mapView.setRegion(mapRegion, animated:true)
            //Adding the current annotation to map
            mapView.addAnnotation(annotationPin as MKAnnotation)
            // Do any additional setup after loading the view.
            // Do any additional setup after loading the view.
            
            
        }
            //Reading data from Restaurants Property list
            //get the path
            let path2 = Bundle.main.path(forResource: "RestaurantsList", ofType: "plist")!
            //read the array
            let resArray:NSArray = NSArray(contentsOfFile:path2)!
            
            //for each item in array ,since each item is dictionary get all the attributes and store in local varaibles.
            for item in resArray {
                
                let dictionary: [String: String] = (item as? Dictionary)!
                res_name = dictionary["Name"]
                res_rating = "Rating :"+dictionary["Rating"]!
                res_latitude = dictionary["Latitude"]
                res_longitude = dictionary["Longitude"]
                //setting the cordinates of the map
                let myLocCoordinate = CLLocationCoordinate2D(latitude: Double(res_latitude)!,longitude: Double(res_longitude)!)
                //Calling the Allcustomannotation constructor with map cordinates and title and subtitle
                let annotationPin = AllCustomAnnotation(coordinate: myLocCoordinate, title: res_name, subtitle: res_rating)
                
                //setting the constraints for the map
                let mapRegion = MKCoordinateRegionMakeWithDistance(myLocCoordinate,1000,1000)
                //setting the map region
            mapView.setRegion(mapRegion, animated:true)
                //Adding the current annotation to map
                mapView.addAnnotation(annotationPin as MKAnnotation)
                // Do any additional setup after loading the view.
                // Do any additional setup after loading the view.
                
            

        // Do any additional setup after loading the view.
   
   
    }
        let path3 = Bundle.main.path(forResource: "AttractionsList", ofType: "plist")!
        //read the array
        let attArray:NSArray = NSArray(contentsOfFile:path3)!
        
        //for each item in array ,since each item is dictionary get all the attributes and store in local varaibles.
        for item in attArray {
            
            let dictionary: [String: String] = (item as? Dictionary)!
            attr_name = dictionary["Name"]
            attr_subtitle = dictionary["Description"]!
            attr_latitude = dictionary["Latitude"]
            attr_longitude = dictionary["Longitude"]
            //setting the cordinates of the map
            let myLocCoordinate = CLLocationCoordinate2D(latitude: Double(attr_latitude)!,longitude: Double(attr_longitude)!)
            //Calling the Allcustomannotation constructor with map cordinates and title and subtitle
            let annotationPin = AllCustomAnnotation(coordinate: myLocCoordinate, title: attr_name, subtitle: attr_subtitle)
            
            //setting the constraints for the map
            let mapRegion = MKCoordinateRegionMakeWithDistance(myLocCoordinate,1000,1000)
            //setting the map region
            mapView.setRegion(mapRegion, animated:true)
            //Adding the current annotation to map
            mapView.addAnnotation(annotationPin as MKAnnotation)
            // Do any additional setup after loading the view.
            // Do any additional setup after loading the view.
            
            
            
            // Do any additional setup after loading the view.
            
            
        }
        }
    //referencing the segment outlet
    @IBOutlet weak var segment_outlet: UISegmentedControl!
    
    //referencing the IBAction for the segment controller
    @IBAction func segment_action(_ sender: UISegmentedControl) {
        let segIndex = sender.selectedSegmentIndex
        //switch to appropriate view if we click on hybrid,satellite or standard.
        switch segIndex{
        case 0:
            mapView.mapType = .standard
        case 1:
            mapView.mapType = .satellite
        case 2:
            mapView.mapType = .hybrid
        default:
            break
        }    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
