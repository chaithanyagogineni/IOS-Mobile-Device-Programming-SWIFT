//
//  Attraction.swift
//  CGogiTopTenMendoza
//
//  Created by Chaithanya Krishna Gogineni on 3/7/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
/*
 This is IOS 521 MID Term Application
 Author :Chaithanya Krishna
 ZID:Z1815642
 MID TERM
 IOS 521  SPRING 2018
 DUE:03-08-2018
 Instructor:Kaisone Rush
 */
//Importing the libraries required
import UIKit
//This class is used to store the details or attributes of a Attraction
class Attraction: NSObject {
    
    //declaring all the required variables
    var attr_name : String!
     var attr_description : String!
     var attr_image : String!
     var attr_address : String!
     var attr_website : String!
     var attr_phone : String!
     var attr_hours : String!
     var attr_people : String!
    var attr_latitude :String!
    var attr_longitude :String!
    
    //intialisation method that helps to initialise the variables of class
    init(attr_name : String!,attr_description : String!,attr_image : String!,attr_address : String!,attr_website : String!,attr_phone : String!,attr_hours : String!,attr_people : String!,attr_latitude : String!,attr_longitude : String!)
     {
        //setting the parameter to current class variables
        self.attr_name = attr_name
        self.attr_description = attr_description
        self.attr_image = attr_image
        self.attr_address = attr_address
        self.attr_website = attr_website
        self.attr_phone = attr_phone
        self.attr_hours = attr_hours
        self.attr_people = attr_people
        self.attr_latitude = attr_latitude
        self.attr_longitude = attr_longitude
    }
    

}//end of class
