//
//  CustomAnnotation.swift
//  CGogiTopTenMendoza
//
//  Created by Chaithanya Krishna Gogineni on 3/8/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
/*
 This is IOS 521 MID Term Application
 Author :Chaithanya Krishna
 ZID:Z1815642
 MID TERM
 IOS 521  SPRING 2018
 DUE:03-08-2018
 Instructor:Kaisone Rush
 */

//Importing the libraries required
import UIKit
import MapKit

//The purpose of this class,this is used to store all the map attributes
class CustomAnnotation: NSObject,MKAnnotation {

    //declaring the varibales required for storing the coordinates of map,title of map,subtile
    var coordinate: CLLocationCoordinate2D
    var title :String?
    var subtitle :String?
    
    //initialsation method to initialise the variables of map
    
    init(coordinate: CLLocationCoordinate2D,title: String,subtitle:String)
    {
        //initialising the parameters of the function to variables of custom annotation class
        self.coordinate=coordinate
        self.title=title
        self.subtitle=subtitle
    }//end of method
}//end of class
