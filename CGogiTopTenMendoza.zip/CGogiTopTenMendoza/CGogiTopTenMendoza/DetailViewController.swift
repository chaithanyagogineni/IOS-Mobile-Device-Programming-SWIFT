//
//  DetailViewController.swift
//  CGogiTopTenMendoza
//
//  Created by Chaithanya Krishna Gogineni on 3/7/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
/*
 This is IOS 521 MID Term Application
 Author :Chaithanya Krishna
 ZID:Z1815642
 MID TERM
 IOS 521  SPRING 2018
 DUE:03-08-2018
 Instructor:Kaisone Rush
 */

//Importing the libraries required
import UIKit

//This is the DetailviewController that acts as a controller for Detail view i.e the second screen from the starting
class DetailViewController: UIViewController {

    //referencing the IB Outlets
    @IBOutlet weak var dvc_image: UIImageView!
    @IBOutlet weak var dvc_phone: UILabel!
    @IBOutlet weak var dvc_address: UILabel!
    @IBOutlet weak var dvc_caption: UILabel!
    @IBOutlet weak var dvc_name: UILabel!
    
//Declaring the hotel attributes
    var hotel_phone: String!
    var hotel_address: String!
    var hotel_caption: String!
    var hotel_name: String!
    var hotel_image: String!
    var hotel_latitude: String!
    var hotel_longitude: String!
    var hotel_website: String!
    var hotel_hours: String!
//Declaring the restaurant attributes
    var res_name: String!
    var res_image: String!
    var res_address: String!
    var res_phone: String!
    var res_rating: String!
    var res_latitude: String!
    var res_longitude: String!
    var res_website: String!
    var res_hours: String!
 //Declaring the attraction attributes
    var attr_name: String!
    var attr_description: String!
    var attr_image: String!
    var attr_address: String!
    var attr_phone: String!
    var attr_hours: String!
    var attr_website: String!
    var attr_latitude: String!
    var attr_longitude: String!
 //Setting the initila flags.
    var hotel_flag = 0
    var res_flag = 0
    var attr_flag = 0
  
    //Implementing the viewDidLoad function
    override func viewDidLoad() {
        super.viewDidLoad()
//If hotel flag is set in view controller then user clicked on hotels
        if (hotel_flag == 1)
        {
            //set the title as hotel name
            self.navigationItem.title=hotel_name
            //set the Detail view controller attributes
         dvc_phone.text = hotel_phone
        dvc_address.text = hotel_address
        dvc_caption.text = hotel_hours
        dvc_name.text = hotel_name
        dvc_image.image = UIImage(named: hotel_image)
        }
            //if res_flag is set to 1.User have selected restaurants
        else if (res_flag == 1)
        {
            //set the navigation title as Restaurant tile
            self.navigationItem.title=res_name
            //setting the attributes of detail view controller
            dvc_phone.text = res_phone
            dvc_name.text = res_name
            dvc_address.text = res_address
            dvc_image.image = UIImage(named: res_image)
            dvc_caption.text = res_hours
        }
            //If the attr_flag is selected,then the attraction is select by user.
        else if (attr_flag == 1)
        {
            //Make the title as Attraction name
            self.navigationItem.title = attr_name
            //Set the detail view controller attributes
          dvc_phone.text = attr_phone
            dvc_address.text = attr_address
            dvc_name.text = attr_name
            dvc_image.image = UIImage(named: attr_image)
            dvc_caption.text = attr_hours
        }
        // Do any additional setup after loading the view.
    }
    //implementing the prepare method
    //The purpose of the function is to set action based on segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        //if the segue identifier is www,then navigate to other screen(website screen)
        if (segue.identifier == "WWW") {
            //move to Website view controller
           let destVC = segue.destination as! WebSiteViewController
            //setting the title
            //if hotel_flag is set ,then set title as hotel name and website as hotel website
            if (hotel_flag == 1)
            {
                
                destVC.navigationItem.title = hotel_name+" "
                destVC.dtvwebsite = hotel_website
            }
                 //if res_flag is set ,then set title as restaurant name and website as restaurant website
            else if (res_flag == 1)
            {
                destVC.navigationItem.title = res_name+" "
                destVC.dtvwebsite = res_website
            }
                 //if attr_flag is set ,then set title as attraction name and website as attraction website
            else if (attr_flag == 1)
            {
                destVC.navigationItem.title = attr_name+" "
                destVC.dtvwebsite = attr_website
            }
            
        }
        //if the segue identifier is GETMAP then navigate Map View Controller
        if (segue.identifier == "GETMAP") {
            let mapVC = segue.destination as! MapViewController
            //setting the title
             //if hotel_flag is set ,then set title as hotel name and set the map view controller attriubtes
            if (hotel_flag == 1)
            {
                mapVC.navigationItem.title = hotel_name+" "
                mapVC.mvc_lat = self.hotel_latitude
                mapVC.mvc_long = self.hotel_longitude
                mapVC.mvc_title = self.hotel_name
                mapVC.mvc_subtitle = self.hotel_caption
            }
                //if res_flag is set ,then set title as restaurant  name and set the map view controller attriubtes
            else if (res_flag == 1)
            {
                mapVC.navigationItem.title = res_name+" "
                mapVC.mvc_lat = self.res_latitude
                mapVC.mvc_long = self.res_longitude
                mapVC.mvc_title = self.res_name
                mapVC.mvc_subtitle = "Rating: "+self.res_rating
                
                
            }
                 //if attr_flag is set ,then set title as attraction  name and set the map view controller attriubtes
            else if (attr_flag == 1)
            {
                mapVC.navigationItem.title = attr_name+" "
                mapVC.mvc_lat = self.attr_latitude
                mapVC.mvc_long = self.attr_longitude
                mapVC.mvc_title = self.attr_name
                mapVC.mvc_subtitle = self.attr_description
            }
            
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
