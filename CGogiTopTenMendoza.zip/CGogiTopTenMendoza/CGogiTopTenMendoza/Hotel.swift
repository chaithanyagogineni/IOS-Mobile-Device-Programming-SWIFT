//
//  Hotel.swift
//  CGogiTopTenMendoza
//
//  Created by Chaithanya Krishna Gogineni on 3/6/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
/*
 This is IOS 521 MID Term Application
 Author :Chaithanya Krishna
 ZID:Z1815642
 MID TERM
 IOS 521  SPRING 2018
 DUE:03-08-2018
 Instructor:Kaisone Rush
 */

//Importing the libraries
import UIKit

//This is swift class helps to store the details of Hotel.This has many attributes and an initialiser method that helps to initilaise the attributes
class Hotel: NSObject {
    //declaring the varibles
    var hotel_name: String!
    var hotel_subtitle: String!
    var hotel_address: String!
    var hotel_phone: String!
    var hotel_image: String!
    var hotel_latitude : String!
    var hotel_longitude : String!
    var hotel_website : String!
    var hotel_hours : String!
    
    //init method for initialising the variables of class
    init(hotel_name: String,hotel_subtitle: String,hotel_address: String,hotel_phone: String,hotel_image: String,hotel_latitude: String,hotel_longitude: String,hotel_website : String!,hotel_hours : String!)
    {
        //initialising parmaters to current class varibales
        self.hotel_name = hotel_name
        self.hotel_subtitle = hotel_subtitle
        self.hotel_address = hotel_address
        self.hotel_phone = hotel_phone
        self.hotel_image = hotel_image
        self.hotel_latitude = hotel_latitude
        self.hotel_longitude = hotel_longitude
        self.hotel_website = hotel_website
        self.hotel_hours = hotel_hours
    }
}
