//
//  MapViewController.swift
//  CGogiTopTenMendoza
//
//  Created by Chaithanya Krishna Gogineni on 3/8/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
/*
 This is IOS 521 MID Term Application
 Author :Chaithanya Krishna
 ZID:Z1815642
 MID TERM
 IOS 521  SPRING 2018
 DUE:03-08-2018
 Instructor:Kaisone Rush
 */
//Importing the  libraries required
import UIKit
import MapKit

//This Class acts as a view controller for Map View.Helps to display a map locatiuon for every object
class MapViewController: UIViewController ,MKMapViewDelegate {

    //referencing the mapview outlet
    @IBOutlet weak var mapView: MKMapView!
   
    //referencing the segment controller action
    @IBAction func mapTypeControl(_ sender: UISegmentedControl) {
        let segIndex = sender.selectedSegmentIndex
        //switch to appropriate view if we click on hybrid,satellite or standard.
        switch segIndex{
        case 0:
            mapView.mapType = .standard
        case 1:
            mapView.mapType = .satellite
        case 2:
            mapView.mapType = .hybrid
        default:
            break
        }
    }
    //declare all the variables of map view controller
    var mvc_lat : String!
    var mvc_long : String!
    var mvc_title : String!
    var mvc_subtitle : String!
    //implementing the function
    override func viewDidLoad() {
        super.viewDidLoad()
        //setting the cordinates of the map
        let myLocCoordinate = CLLocationCoordinate2D(latitude: Double(mvc_lat)!,longitude: Double(mvc_long)!)
        //sending the data values to custom annotation
        
        //Calling the custom annotation constructor with map cordinates and title and subtitle
        let annotationPin = CustomAnnotation(coordinate: myLocCoordinate, title: mvc_title, subtitle: mvc_subtitle)
        
        //setting the constraints for the map
        let mapRegion = MKCoordinateRegionMakeWithDistance(myLocCoordinate,500,500)
        //setting the map region
        mapView.setRegion(mapRegion, animated:true)
        //Adding the current annotation to map
        mapView.addAnnotation(annotationPin as MKAnnotation)
        // Do any additional setup after loading the view.
        // Do any additional setup after loading the view.
    }
    //referening the segment controller outlet
    @IBOutlet weak var mapTypeSegment: UISegmentedControl!
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}//end of class
