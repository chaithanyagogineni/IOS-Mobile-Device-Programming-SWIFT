//
//  Restaurant.swift
//  CGogiTopTenMendoza
//
//  Created by Chaithanya Krishna Gogineni on 3/7/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
/*
 This is IOS 521 MID Term Application
 Author :Chaithanya Krishna
 ZID:Z1815642
 MID TERM
 IOS 521  SPRING 2018
 DUE:03-08-2018
 Instructor:Kaisone Rush
 */

//Importing the libraries required
import UIKit

//This class is used to store the details or attributes of a restaurant
class Restaurant: NSObject {
    
    //declaring all the variables required
    var res_name: String!
    var res_rating: String!
    var res_image: String!
    var res_hours: String!
    var res_address: String!
    var res_phone: String!
    var res_latitude: String!
    var res_longitude: String!
    var res_website: String!
    //This is initialise method that helps to initialise the variables of class
    init(res_name : String, res_rating : String,res_image : String, res_hours : String,
         res_address : String, res_phone : String,res_latitude : String,res_longitude :String,res_website : String)
    {
        //setting the parameter to current class variables
        self.res_name = res_name
        self.res_rating = res_rating
        self.res_hours = res_hours
        self.res_image = res_image
        self.res_address = res_address
        self.res_phone = res_phone
        self.res_latitude = res_latitude
        self.res_longitude = res_longitude
        self.res_website = res_website
    }

}
//end of class
