//
//  TableViewCell.swift
//  CGogiTopTenMendoza
//
//  Created by Chaithanya Krishna Gogineni on 3/7/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
/*
 This is IOS 521 MID Term Application
 Author :Chaithanya Krishna
 ZID:Z1815642
 MID TERM
 IOS 521  SPRING 2018
 DUE:03-08-2018
 Instructor:Kaisone Rush
 */
//Importing the libraries required
import UIKit

//This is class of type UITableViewCell.This class is used to hold the data for the cell that appears on the table view
class TableViewCell: UITableViewCell {

    //referencing the outlets
    //referencing the UI label
    @IBOutlet weak var cellSubTitleView: UILabel!
     //referencing the UI label
    @IBOutlet weak var cellTitleView: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
     //referencing the UIimageView
    @IBOutlet weak var cellImageView: UIImageView!
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
