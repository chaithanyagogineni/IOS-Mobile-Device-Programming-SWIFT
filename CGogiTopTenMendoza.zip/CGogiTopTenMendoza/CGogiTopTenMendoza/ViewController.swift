//
//  ViewController.swift
//  CGogiTopTenMendoza
//
//  Created by Chaithanya Krishna Gogineni on 3/5/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//

/*
 This is IOS 521 MID Term Application
 Author :Chaithanya Krishna
 ZID:Z1815642
 MID TERM
 IOS 521  SPRING 2018
 DUE:03-08-2018
 Instructor:Kaisone Rush
 */

//The purpose of this class is this acts as a controller for first view that appears to user
//importing the libraries
import UIKit


class ViewController: UIViewController , UITableViewDelegate, UITableViewDataSource{

    //referencing the outlets
    //referencing teh table view
    @IBOutlet weak var tableView: UITableView!
    
    //referemncing the segment controller outlet
    @IBOutlet weak var segment_outlet: UISegmentedControl!
    
    //referencing the segment controller action
    @IBAction func segmentControllerActionChanged(_ sender: Any) {
        
        //Every time the table view loads just reload the data
        
        tableView.reloadData()
    }

    //Creating the objects for HOTEL,ATTRACTIONS AND RESTAUTRANTS
    var hotelObject = [Hotel]()
    var resObject = [Restaurant]()
    var attrObject = [Attraction]()
    
    //Implementing the viewDidLoad()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //Setting the height of table view
        
        self.tableView.rowHeight = 100
        //Calling the function that adds the info button at the top
        
       addRightNavigationBarInfoButton()
        
        //reading the data from the propertuy list
        readPropertyList()
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    //This function takes no parameters.used top add INFO button at the top
    func addRightNavigationBarInfoButton() {
        
        // Create an Info Light button
        let button = UIButton(type: .infoDark)
        button.addTarget(self, action: #selector(self.showAboutAppView), for: .touchUpInside)
        
        // Place the button at the top right corner of the navigation bar
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(customView: button)
    }
    
    //This is the funciton called by previous fucntion.This instantiates a new controller with ID as AboutApp and helps to navigate there
    @objc func showAboutAppView() {
        //getting the current storyboard with id Main
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        //getting the controller with id AboutApp
        let controller = storyboard.instantiateViewController(withIdentifier: "AboutApp") as UIViewController
        //Pushing to that controller obtained above
        navigationController?.pushViewController(controller, animated: true)
        
    }
    //This function helps to read data from the existing property list and stores them in the objects created at the top
    func readPropertyList()
    {
        //Reading data from hotels Property list
        //get the path
        let path = Bundle.main.path(forResource: "HotelsList", ofType: "plist")!
        //read the array
        let hotelArray:NSArray = NSArray(contentsOfFile:path)!
        
        //for each item in array ,since each item is dictionary get all the attributes and store in local varaibles.pass those variables to hotel constructor
        for item in hotelArray {
            
            let dictionary: [String: String] = (item as? Dictionary)!
            
            let hotel_name = dictionary["Name"]
            let hotel_subtitle = dictionary["Subtitle"]
            let hotel_address = dictionary["Address"]
            let hotel_phone = dictionary["Phone"]
            let hotel_image = dictionary["Image"]
            let hotel_latitude = dictionary["Latitude"]
            let hotel_longitude = dictionary["Longitude"]
            let hotel_website = dictionary["Website"]
            let hotel_hours = dictionary["Hours"]
            //calling the constructor to store data read
            hotelObject.append(Hotel(hotel_name: hotel_name!, hotel_subtitle: hotel_subtitle!, hotel_address: hotel_address!,hotel_phone: hotel_phone!, hotel_image: hotel_image!,hotel_latitude : hotel_latitude!,hotel_longitude : hotel_longitude!,hotel_website : hotel_website!,hotel_hours : hotel_hours!))
        }
        //reading data from teh restaurants property list
        //get the path
        let path2 = Bundle.main.path(forResource: "RestaurantsList", ofType: "plist")!
        //read the array
        let resArray:NSArray = NSArray(contentsOfFile:path2)!
        
        //for each item in array ,since each item is dictionary get all the attributes and store in local varaibles.pass those variables to Restaurant  constructor
        for item in resArray {
            
            let dictionary: [String: String] = (item as? Dictionary)!
            
            let res_name = dictionary["Name"]
            let res_rating = dictionary["Rating"]
            let res_address = dictionary["Address"]
            let res_phone = dictionary["Phone"]
            let res_image = dictionary["Image"]
            let res_hours = dictionary["Hours"]
            let res_latitude = dictionary["Latitude"]
            let res_longitude = dictionary["Longitude"]
            let res_website = dictionary["Website"]
            //calling the constructor to store data read
            resObject.append(Restaurant(res_name: res_name!, res_rating: res_rating!,res_image: res_image!,res_hours: res_hours!, res_address: res_address!,res_phone: res_phone!,res_latitude: res_latitude!,res_longitude: res_longitude!,res_website : res_website!))
        }
        //reading data from teh Attractions property list
        //get the path
        let path3 = Bundle.main.path(forResource: "AttractionsList", ofType: "plist")!
        //reading the data into array
        let attrArray:NSArray = NSArray(contentsOfFile:path3)!
        
        
        //for each item in array ,since each item is dictionary get all the attributes and store in local varaibles.pass those variables to Attraction constructor
        for item in attrArray {
            
            let dictionary: [String: String] = (item as? Dictionary)!
            
            let attr_name = dictionary["Name"]
            let attr_description = dictionary["Description"]
            let attr_image = dictionary["Image"]
            let attr_address = dictionary["Address"]
            let attr_website = dictionary["Website"]
            let attr_phone = dictionary["Phone"]
            let attr_hours = dictionary["Hours"]
            let attr_people = dictionary["People"]
            let attr_latitude = dictionary["Latitude"]
            let attr_longitude = dictionary["Longitude"]
            //calling the constructor to store data read
            attrObject.append(Attraction(attr_name: attr_name!, attr_description: attr_description!,attr_image: attr_image!,attr_address : attr_address!,attr_website : attr_website!,attr_phone: attr_phone!,attr_hours: attr_hours!, attr_people: attr_people!,attr_latitude: attr_latitude!,attr_longitude: attr_longitude! ))
        }
    }
    
    //Returing the number of sections of table view
    public func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    //Table view functiuon that reads the current segment controller outlet value and return the count of object having that index
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        //initialsed a local variable
        var count = 0
        //switch case to check the index of segment controller
        switch segment_outlet.selectedSegmentIndex
        {
            //if index is zero store  Attraction object count in local variable
        case 0:
            count = attrObject.count
            break
            //if index is one store Hotel object count in local variable
        case 1:
            count = hotelObject.count
            break
             //if index is Two store restaurant object count in local variable
        case 2:
            count = resObject.count
            break
        default:
            break
        }//End of Switch
        //finally return local variable with count of specific object based on index
        return count
    }
    //This function sets the data for each cell.
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // Assign a table view cell with the TableViewCell class
        //Find the cell with Identifier as "CEL"
        var cell = tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath) as! TableViewCell
    
         //switch case to act based  the value of the segment controller outlet
       switch segment_outlet.selectedSegmentIndex
       {
        //if index is 0,then fetch data from attraction object and add to cell
       case 0:
        let attr:Attraction = attrObject[indexPath.row]
        cell = tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath) as! TableViewCell
        //place the data of attraaction like name ,image and people visited into cell
        let cellImageName = UIImage(named: attr.attr_image)
        cell.cellImageView.image = cellImageName
        cell.cellTitleView.text = attr.attr_name
        cell.cellSubTitleView.text = attr.attr_people
        break
        //if index is 1,then fetch data from hotel object and add to cell
       case 1:
        let hotel:Hotel = hotelObject[indexPath.row]
        cell = tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath) as! TableViewCell
        // Place hotel data into cell
        let cellImageName = UIImage(named: hotel.hotel_image)
        cell.cellImageView.image = cellImageName
        cell.cellTitleView.text = hotel.hotel_name
        cell.cellSubTitleView.text = hotel.hotel_subtitle
        break
        //if index is 2,then fetch data from Restaurant object and add to cell
       case 2:
        let res:Restaurant = resObject[indexPath.row]
         cell = tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath) as! TableViewCell
        //Place the data of restaurant into the cell
        
        let cellImageName = UIImage(named: res.res_image)
        cell.cellImageView.image = cellImageName
        cell.cellTitleView.text = res.res_name
        cell.cellSubTitleView.text = "Rating: "+res.res_rating
        break
       default:
        break
       }//End of switch
        
    //Finally return the Cell that appears on the table view
        return cell
    }
    
    //Function that helps to perform an action based on segue
    public override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // First identify the DetailViewController as the destination view controller
        if (segue.identifier == "DetailView") {
            //switch case to act based on the segment_outlet index
            switch segment_outlet.selectedSegmentIndex
            {
            //If the index of segment_outlet is 0,then set the attraction attributes in the detail view controller
            case 0:
                let destVC = segue.destination as! DetailViewController
                if let indexPath = self.tableView.indexPathForSelectedRow {
                    let attr:Attraction = attrObject[indexPath.row]
                    
                    //Setting the attributes of detail view controller
                    destVC.attr_flag = 1
                    destVC.attr_name = attr.attr_name
                    destVC.attr_image = attr.attr_image
                    destVC.attr_hours = attr.attr_hours
                    destVC.attr_address = attr.attr_address
                    destVC.attr_phone = attr.attr_phone
                    destVC.attr_website = attr.attr_website
                    destVC.attr_latitude = attr.attr_latitude
                    destVC.attr_longitude = attr.attr_longitude
                    destVC.attr_description = attr.attr_description
                    
                    
            }
                break
                 //If the index of segment_outlet is 1,then set the Hotel attributes in the detail view controller
            case 1:
                let destVC = segue.destination as! DetailViewController
                if let indexPath = self.tableView.indexPathForSelectedRow {
                    let hotel:Hotel = hotelObject[indexPath.row]
                    
                    //Setting the attributes of detail view controller
                    destVC.hotel_flag = 1 
                    destVC.hotel_name = hotel.hotel_name
                    destVC.hotel_image = hotel.hotel_image
                    destVC.hotel_caption = hotel.hotel_subtitle
                    destVC.hotel_address = hotel.hotel_address
                    destVC.hotel_phone = hotel.hotel_phone
                    destVC.hotel_latitude = hotel.hotel_latitude
                    destVC.hotel_longitude = hotel.hotel_longitude
                    destVC.hotel_website = hotel.hotel_website
                    destVC.hotel_hours = hotel.hotel_hours
                    
                    
                }
                break
                //If the index of segment_outlet is 2,then set the Restaurant attributes in the detail view controller
            case 2:
                let destVC = segue.destination as! DetailViewController
                if let indexPath = self.tableView.indexPathForSelectedRow {
                    destVC.res_flag = 1
                    let res:Restaurant = resObject[indexPath.row]
                    //setting the attributes of detail view controller
                    destVC.res_name = res.res_name
                    destVC.res_image = res.res_image
                    destVC.res_address = res.res_address
                    destVC.res_phone = res.res_phone
                    destVC.res_rating = res.res_rating
                    destVC.res_latitude = res.res_latitude
                    destVC.res_longitude = res.res_longitude
                    destVC.res_website = res.res_website
                    destVC.res_hours = res.res_hours
                    
                }
                break
            default:
                break
            }//End switch
        } // end if
    }//End of function


}

