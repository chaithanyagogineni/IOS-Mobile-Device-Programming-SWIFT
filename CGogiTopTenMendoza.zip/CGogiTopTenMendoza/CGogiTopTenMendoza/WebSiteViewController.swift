//
//  WebSiteViewController.swift
//  CGogiTopTenMendoza
//
//  Created by Chaithanya Krishna Gogineni on 3/8/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
/*
 This is IOS 521 MID Term Application
 Author :Chaithanya Krishna
 ZID:Z1815642
 MID TERM
 IOS 521  SPRING 2018
 DUE:03-08-2018
 Instructor:Kaisone Rush
 */
//Importing the libraries required
import UIKit
import WebKit

//The purpose of this class is it acts as a view copntroller for Website of object(attraction or restaurant or hotel)
class WebSiteViewController: UIViewController {

    //referencing the webkit view outlet
    @IBOutlet weak var webView: WKWebView!
    
    //declaring a variable to store website
    var dtvwebsite : String!
    
    //implementing the function
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Setting the URL as the website variable
        let myURL = URL(string: dtvwebsite)
        
        // Create a request with the URL string.
        let urlRequest = URLRequest(url: myURL!)
        
        // Load the website with the URL request.
        webView.load(urlRequest)          // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}//End of class
