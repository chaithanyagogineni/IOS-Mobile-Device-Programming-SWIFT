//
//  AboutAppViewController.swift
//  Gogi-FoundingFathers
//
//  Created by Chaithanya Krishna Gogineni on 3/1/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//

/*
 Author:Chaithanya Krishna
 Spring 2018
 IOS 321/521
 Assignment 3
 */
//The purpose of this class is this acts as controleller for App view
//This sets the
import UIKit

class AboutAppViewController: UIViewController {
    // This function navigate to the "About Author" view when
    // the "About Author" button is pressed.
        @IBAction func aboutAuthorButton(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let destinationVC = storyboard.instantiateViewController(withIdentifier: "AuthorViewController") as! AboutAuthorViewController
        self.navigationController?.pushViewController(destinationVC, animated: true)
        
    }
    //implementing the viewdidload method
    override func viewDidLoad() {
        super.viewDidLoad()
        //setting the title of the view
        navigationItem.title = "About App"

        // Do any additional setup after loading the view.
    }

    

    
}
