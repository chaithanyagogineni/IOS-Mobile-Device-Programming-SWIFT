//
//  AboutAuthorViewController.swift
//  Gogi-FoundingFathers
//
//  Created by Chaithanya Krishna Gogineni on 3/1/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//

/*
 Author:Chaithanya Krishna
 Spring 2018
 IOS 321/521
 Assignment 3
 */
//The purpose of the class is this acts as controller for About author view

//Importing the header files required
import UIKit
import WebKit

//This class is of type UIViewController
class AboutAuthorViewController: UIViewController {

    //referencing the outlets .
    //referencing the webkit view
    @IBOutlet weak var webView: WKWebView!
    
    //Implementing the viewdidload fucntion
    override func viewDidLoad() {
        super.viewDidLoad()
        //setting the navigation title
        navigationItem.title = "About Author"
        
        // Create a path to the index.html "data" file bundled under the "html" folder
        let path = Bundle.main.path(forResource: "html/index", ofType: "html")!
        let webData: Data = try! Data(contentsOf: URL(fileURLWithPath: path))
        let html = NSString(data: webData, encoding: String.Encoding.utf8.rawValue)
        
        // Load the webView outlet with the content of the index.html file
        self.webView.loadHTMLString(html! as String, baseURL: Bundle.main.bundleURL)
        // Do any additional setup after loading the view.
    }

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
