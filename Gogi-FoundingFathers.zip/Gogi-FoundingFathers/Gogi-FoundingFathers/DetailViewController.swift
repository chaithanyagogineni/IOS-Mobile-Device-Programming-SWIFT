//
//  DetailViewController.swift
//  Gogi-FoundingFathers
//
//  Created by Chaithanya Krishna Gogineni on 2/26/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
/*
 Author:Chaithanya Krishna
 Spring 2018
 IOS 321/521
 Assignment 3
 */
//Purpose of this class:This class acts as controller for detail view screem=n.
//This is of type UIView Controller

//Importing the libraries
import UIKit

class DetailViewController: UIViewController {

   //referencing the IBOutlets of class.
   
    //referencing the UIImageView outlet.
    
    @IBOutlet weak var fatherImageView: UIImageView!
    
    
   
   //referencing the UILabel outlet for displaying father title
    @IBOutlet weak var fatherTitle: UILabel!
    
    //referencing the UILabel outlet for displaying father party
    @IBOutlet weak var fatherParty: UILabel!
  
    //referencing the UILabel outlet for displaying father spouse
    @IBOutlet weak var fatherSpouse: UILabel!
    
   
    //declaring the varibales required
    var tvFatherName:String!
    var tvFatherImage:String!
    var tvFatherTitle:String!
    var tvFatherYears:String!
    var tvFatherSpouse:String!
    var tvFatherParty:String!
    var tvWebSite:String!
    
    //Implementing the ViewDidLoad function
    override func viewDidLoad() {
        super.viewDidLoad()
        // Place sent data into their outlets
        //setting the navigation title as father name
        navigationItem.title = tvFatherName
        //setting the father image
        fatherImageView.image = UIImage(named: tvFatherImage)
        //setting the father title
        fatherTitle.text = tvFatherTitle
        //setting the father party
        fatherParty.text = tvFatherParty
        //setting the father spouse
        fatherSpouse.text = tvFatherSpouse
    }
    
    //implementing the prepare method
    //The purpose of the function is to set action based on segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
    //if the segue identifier is www,then navigate to other screen(website screen)
        if (segue.identifier == "WWW") {
            let destVC = segue.destination as! WebSiteViewController
            //setting the title
            destVC.navigationItem.title = tvFatherName+" PRESIDENT "
            destVC.dtvFatherWebSite = tvWebSite
        }
    }
    //implementing the didrecievememorywarning method
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
}
