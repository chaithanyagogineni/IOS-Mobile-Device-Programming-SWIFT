//
//  Father.swift
//  Gogi-FoundingFathers
//
//  Created by Chaithanya Krishna Gogineni on 2/26/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
//purpose:Used to store all the details of the each father.
/*
 
 Author:Chaithanya Krishna
 Spring 2018
 IOS 321/521
 Assignment 3
 
 */
//This is father class.this is used to store detailsof each father.
//Importing the libraries
import UIKit
import Foundation

class Father: NSObject {
    //declaring all the variables
    var number:String!
    var name: String!
    var title:String!
    var years:String!
    var spouse:String!
    var party:String!
    var image_cell:String!
    var image:String!
    var website:String!
    
    // Setup initialization method
    //This is initializer method .This helps to initialse all the variables of class
    //takes all the parameters available in the class.
    //all are strings
    init(number: String,name: String, title: String, years: String, spouse: String, party: String, image_cell: String, image: String ,website: String) {
        self.number = number
        self.name = name
        self.title = title
        self.years = years
        self.spouse = spouse
        self.party = party
       self.website = website
        self.image_cell = image_cell
        self.image = image
    }}
