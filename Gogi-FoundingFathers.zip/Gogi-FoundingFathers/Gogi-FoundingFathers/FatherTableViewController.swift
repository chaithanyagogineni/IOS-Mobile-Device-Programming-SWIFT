//
//  FatherTableViewController.swift
//  Gogi-FoundingFathers
//
//  Created by Chaithanya Krishna Gogineni on 2/26/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
//Purpose:The purpose of this class is to act as a view controller first screen.It reads all the data from propeerty list and displays the data on each cell of table.
/*
 Author:Chaithanya Krishna
 Spring 2018
 IOS 321/521
 Assignment 3
 */
//importing header files required
import UIKit

class FatherTableViewController: UITableViewController {
//creating an object of type father
    var fatherObject = [Father]()
    
    //implementing view DidLoad function
    override func viewDidLoad() {
        super.viewDidLoad()
        //Setting the table height
        self.tableView.rowHeight = 100
        //Calling method that helps to read data from property list
        readPropertyList()
        
    }
    
    
   //Implementing the readproperty list function.
    /*
     Purpose:This purpose is to read data from property list and store it in object of father
 */
    
    func readPropertyList() {
        //reading the path of property list
        let path = Bundle.main.path(forResource: "FoundingFathers", ofType: "plist")!
        let fatherArray:NSArray = NSArray(contentsOfFile:path)!
        
        //Iterating through the property list
        
        for item in fatherArray {
            //item is of type Any Object and it cannot be used
            //as a subscripted dictionary with value-key pair.
            //Therefore, I need to convert item into a dictionary.
            let dictionary: [String: String] = (item as? Dictionary)!
            
            //Next, use "dictionary" to extract each attribute
            //in the dictionary before appending them in the
            //fatherObject.
            let father_number=dictionary["Number"]
            let father_name = dictionary["Name"]
            let father_title = dictionary["Title"]
            let father_years = dictionary["Years"]
            let father_spouse = dictionary["Spouse"]
            let father_party = dictionary["Party"]
            let father_www = dictionary["www"]
            let image_cell = dictionary["Image-cell"]
            let father_image = dictionary["Image"]
           //Calling the constructor to set all the attributes of the father
            fatherObject.append(Father(number: father_number!,name: father_name!, title: father_title!, years: father_years!, spouse: father_spouse!, party: father_party!, image_cell: image_cell!, image: father_image!, website: father_www!))
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    //return the number of sections
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // return the number of rows in father object
        return fatherObject.count
    }
    //This function sets the data for each cell.
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let father:Father = fatherObject[indexPath.row]
        
        // Assign a table view cell with the TableViewCell class
        let cell = tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath) as! TableViewCell
        
        // Place cell image, fatherr name and years in the table cell
        let cellImageName = UIImage(named: father.image_cell)
        cell.cellImageView.image = cellImageName
        cell.cellTitleLabel.text = father.name
        cell.cellSubTitleLabel.text = father.years
        return cell
    }
    
    //Setting the varibale of the destination view controller
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // First identify the DetailViewController as the destination view controller
        if (segue.identifier == "DetailView") {
            let destVC = segue.destination as! DetailViewController
            
            // Prepare to send father image, father name,spouse and title
            // DetailViewController
            if let indexPath = self.tableView.indexPathForSelectedRow {
                let father:Father = fatherObject[indexPath.row]
                destVC.tvFatherName = father.name
                destVC.tvFatherImage = father.image
                destVC.tvFatherTitle = father.title
                destVC.tvFatherSpouse = father.spouse
                destVC.tvFatherParty = father.party
                destVC.tvWebSite = father.website
                
               
            } // end if
        } // end if
    }

   


   
    

    
}
