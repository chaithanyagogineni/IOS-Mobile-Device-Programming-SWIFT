//
//  TableViewCell.swift
//  Gogi-FoundingFathers
//
//  Created by Chaithanya Krishna Gogineni on 2/26/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
/*
 Author:Chaithanya Krishna
 Spring 2018
 IOS 321/521
 Assignment 3
 */
//Purpose :This class acts as controller for the table view .this helps to reference the cell attributes like image,title and subtitle to class
import UIKit

class TableViewCell: UITableViewCell {
  
    //referencing the IBOutlets
    //referencing the UIImage View outlet
    @IBOutlet weak var cellImageView: UIImageView!
    
    //referncing the UILabel outlet
    @IBOutlet weak var cellTitleLabel: UILabel!
    
    //referencing the UILabel outlet
    @IBOutlet weak var cellSubTitleLabel: UILabel!
    
    //Implementing the awakeFromNib function
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    //Implementing the setSelected function.
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
