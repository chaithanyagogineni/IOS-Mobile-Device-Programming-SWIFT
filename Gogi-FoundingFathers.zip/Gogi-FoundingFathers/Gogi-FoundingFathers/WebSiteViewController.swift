//
//  WebSiteViewController.swift
//  Gogi-FoundingFathers
//
//  Created by Chaithanya Krishna Gogineni on 2/26/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//

/*
 Author:Chaithanya Krishna
 Spring 2018
 IOS 321/521
 Assignment 3
 */

//importing the libraries required
import UIKit
import WebKit

//purpose :This class acts as a controller for website view.this class loads the site of particular president
class WebSiteViewController: UIViewController {

    //Referencing the outlets
    @IBOutlet weak var webView: WKWebView!
    //declaring the varibales
    var dtvFatherWebSite:String!
    //implementing the function viewDidLoad()
    override func viewDidLoad() {
        super.viewDidLoad()

        // Create a URL string object and initialize it to
        // the string passed from the detail VC.
        let myURL = URL(string: dtvFatherWebSite)
        
        // Create a request with the URL string.
        let urlRequest = URLRequest(url: myURL!)
        
        // Load the website with the URL request.
        webView.load(urlRequest)        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    

}
