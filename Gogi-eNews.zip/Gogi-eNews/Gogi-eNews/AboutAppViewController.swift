//
//  AboutAppViewController.swift
//  Gogi-eNews
//
//  Created by Chaithanya Krishna Gogineni on 4/26/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
/*
 This is IOS 521 Assignment 7
 name : enews Application
 Author :Chaithanya Krishna
 ZID:Z1815642
 IOS 521  SPRING 2018
 DUE:04-30-2018
 Instructor:Kaisone Rush
 */
import UIKit
import MessageUI
//The purpose of this is it acts as view comntroller for about app view
class AboutAppViewController: UIViewController ,MFMailComposeViewControllerDelegate{

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "About App"

        // Do any additional setup after loading the view.
    }

    @IBAction func aboutAuthor(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let destinationVC = storyboard.instantiateViewController(withIdentifier: "AboutAuthorViewController") as! AuthorViewController
        self.navigationController?.pushViewController(destinationVC, animated: true)
    }
    
    //Implementing the email functionality
    @IBAction func sendFeedback(_ sender: Any) {
        
        let mailComposeVC = MFMailComposeViewController()
        
        mailComposeVC.mailComposeDelegate = self
        
        //setting the variables
        let toRecipients = ["niucsci@gmail.com"]
        let emailTitle = " App Feedback"
        let messageBody = "Sample Text"
        
        //Calling the functions that helps to send the required receipents
        mailComposeVC.setToRecipients(toRecipients)
        //Function that helps to set the title of the email
        mailComposeVC.setSubject(emailTitle)
        //Setting the Mesage Body
        mailComposeVC.setMessageBody(messageBody, isHTML: false)
        
        self.present(mailComposeVC, animated: true, completion: nil)
    }
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        
        switch result.rawValue {
            
        case MFMailComposeResult.cancelled.rawValue:
            print("cancelled")
            
        case MFMailComposeResult.failed.rawValue:
            print("failed")
            
        case MFMailComposeResult.saved.rawValue:
            print("saved")
            
        case MFMailComposeResult.sent.rawValue:
            print("sent")
            
        default:
            break
            
        }
        
        // Dismiss the compose view controller after the ComposeVC
        // finishes.
        self.dismiss(animated: true, completion: nil)
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

   

}
