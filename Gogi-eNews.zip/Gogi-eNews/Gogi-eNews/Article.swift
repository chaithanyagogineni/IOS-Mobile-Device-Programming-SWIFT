//
//  Article.swift
//  Gogi-eNews
//
//  Created by Chaithanya Krishna Gogineni on 4/26/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
/*
 This is IOS 521 Assignment 7
 name : enews Application
 Author :Chaithanya Krishna
 ZID:Z1815642
 IOS 521  SPRING 2018
 DUE:04-30-2018
 Instructor:Kaisone Rush
 */
import UIKit
//The purpose of this class is to load the data of each article
class Article: NSObject {
    
        var id : String!
        var name : String!
        var author : String!
        var title : String!
        var desc : String!
        var url : String!
        var urlToimage : String!
        var publishedAt : String!
    
    //initilasing the variables of class
    
    init(id : String, name : String, author : String , title : String, desc : String , url : String , urlToimage : String ,publishedAt : String) {
        self.id = id
        self.name = name
        self.author = author
        self.title = title
        self.desc = desc
        self.url = url
        self.urlToimage = urlToimage
        self.publishedAt = publishedAt
        
    }
    
}
