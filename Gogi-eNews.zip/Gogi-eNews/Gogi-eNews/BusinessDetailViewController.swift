//
//  BusinessDetailViewController.swift
//  Gogi-eNews
//
//  Created by Chaithanya Krishna Gogineni on 4/30/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
/*
 This is IOS 521 Assignment 7
 name : enews Application
 Author :Chaithanya Krishna
 ZID:Z1815642
 IOS 521  SPRING 2018
 DUE:04-30-2018
 Instructor:Kaisone Rush
 */
//Importing the libraries required
import UIKit

//This class acts as view controller for detail view of business breaking news
class BusinessDetailViewController: UIViewController {

    //referencing the outlets
    @IBOutlet weak var busDetailDesc: UILabel!
    @IBOutlet weak var busDetailTitle: UILabel!
    @IBOutlet weak var busDetailAuthor: UILabel!
    @IBOutlet weak var busDetailImage: UIImageView!
    //declaring the varaibels requireed
    var bustitle : String!
    var busauthor : String!
    var busdesc : String!
    var busimage : String!
    var buswebsite : String!
    var busHead : String!
    override func viewDidLoad() {
        super.viewDidLoad()
        //initialsing the variables
       self.busDetailAuthor.text = busauthor
        self.busDetailDesc.text = busdesc
        self.busDetailTitle.text = bustitle
        navigationItem.title = busHead
        if let url = URL(string: busimage!){
            do{
                let x = try Data(contentsOf: url)
                self.busDetailImage.image = UIImage(data:x);
            }
            catch let ImageError {
                print("Unable to read image")
            }
        }
        // Do any additional setup after loading the view.
    }
    //implementing the segue for the website
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        //if the segue identifier is www,then navigate to other screen(website screen)
        if (segue.identifier == "bwww") {
            let destVC = segue.destination as! BusinessWebsiteViewController
            //setting the title
            destVC.navigationItem.title = "Website"
            destVC.dtvBusinessSite = buswebsite
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


}
