//
//  BusinessTableViewCell.swift
//  Gogi-eNews
//
//  Created by Chaithanya Krishna Gogineni on 4/27/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
/*
 This is IOS 521 Assignment 7
 name : enews Application
 Author :Chaithanya Krishna
 ZID:Z1815642
 IOS 521  SPRING 2018
 DUE:04-30-2018
 Instructor:Kaisone Rush
 */
//Importing the libraries required
import UIKit
//The purpose of this class is it acts as table view cell for Business
class BusinessTableViewCell: UITableViewCell {

    //referencing the outlets required
    @IBOutlet weak var busPublish: UILabel!
    @IBOutlet weak var busSourceName: UILabel!
    @IBOutlet weak var busTitle: UILabel!
    @IBOutlet weak var busImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

