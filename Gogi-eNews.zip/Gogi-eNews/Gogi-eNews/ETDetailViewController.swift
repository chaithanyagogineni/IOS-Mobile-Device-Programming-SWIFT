//
//  ETDetailViewController.swift
//  Gogi-eNews
//
//  Created by Chaithanya Krishna Gogineni on 4/30/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
/*
 This is IOS 521 Assignment 7
 name : enews Application
 Author :Chaithanya Krishna
 ZID:Z1815642
 IOS 521  SPRING 2018
 DUE:04-30-2018
 Instructor:Kaisone Rush
 */
//Importing the libraries required
import UIKit
//This class acts as a view controller for Entertainment breaking news
class ETDetailViewController: UIViewController {
 
    //referencing the variables required
    @IBOutlet weak var etDetailDesc: UILabel!
    @IBOutlet weak var etDetailTitle: UILabel!
    @IBOutlet weak var etDetailImage: UIImageView!
    
    @IBOutlet weak var etDetailAuthor: UILabel!
    //declaring the variables required
    var enttitle : String!
    var entauthor : String!
    var entdesc : String!
    var entimage : String!
    var entwebsite : String!
    var enthead : String!
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = enthead
        self.etDetailAuthor.text = entauthor
        self.etDetailDesc.text = entdesc
        self.etDetailTitle.text = enttitle
        if let url = URL(string: entimage!){
            do{
                let x = try Data(contentsOf: url)
                self.etDetailImage.image = UIImage(data:x);
            }
            catch let ImageError {
                print("Unable to read image")
            }
        }
        // Do any additional setup after loading the view.
        // Do any additional setup after loading the view.
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        //if the segue identifier is www,then navigate to other screen(website screen)
        if (segue.identifier == "ewww") {
            let destVC = segue.destination as! ETWebsiteViewController
            //setting the title
            destVC.navigationItem.title = "Website"
            destVC.dtvEntSite = entwebsite
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
