//
//  ETWebsiteViewController.swift
//  Gogi-eNews
//
//  Created by Chaithanya Krishna Gogineni on 4/30/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
/*
 This is IOS 521 Assignment 7
 name : enews Application
 Author :Chaithanya Krishna
 ZID:Z1815642
 IOS 521  SPRING 2018
 DUE:04-30-2018
 Instructor:Kaisone Rush
 */
//Importing the libraries required
import UIKit
import WebKit

//Purpose is to load the web site of an article
class ETWebsiteViewController: UIViewController {
//referencing the outlets
    @IBOutlet weak var webView: WKWebView!
    var dtvEntSite : String!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Create a URL string object and initialize it to
        // the string passed from the detail VC.
        let myURL = URL(string: dtvEntSite)
        
        // Create a request with the URL string.
        let urlRequest = URLRequest(url: myURL!)
        
        // Load the website with the URL request.
        webView.load(urlRequest)        // Do any additional setup after loading the view.
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
}


/*
 // MARK: - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
 // Get the new view controller using segue.destinationViewController.
 // Pass the selected object to the new view controller.
 }
 */
}
