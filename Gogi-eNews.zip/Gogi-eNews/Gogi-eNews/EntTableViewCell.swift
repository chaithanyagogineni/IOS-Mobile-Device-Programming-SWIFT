//
//  EntTableViewCell.swift
//  Gogi-eNews
//
//  Created by Chaithanya Krishna Gogineni on 4/30/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
/*
 This is IOS 521 Assignment 7
 name : enews Application
 Author :Chaithanya Krishna
 ZID:Z1815642
 IOS 521  SPRING 2018
 DUE:04-30-2018
 Instructor:Kaisone Rush
 */
//Importing the libraries required
import UIKit
//This is a table view cell for the Entertainment
class EntTableViewCell: UITableViewCell {

    //referencing the outlets required
    @IBOutlet weak var entPublish: UILabel!
    @IBOutlet weak var entSource: UILabel!
    @IBOutlet weak var entTitle: UILabel!
    @IBOutlet weak var entImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
