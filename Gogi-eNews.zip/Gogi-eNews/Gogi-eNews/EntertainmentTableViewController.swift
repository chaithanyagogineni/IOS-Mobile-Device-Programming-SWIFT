//
//  EntertainmentTableViewController.swift
//  Gogi-eNews
//
//  Created by Chaithanya Krishna Gogineni on 4/30/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
/*
 This is IOS 521 Assignment 7
 name : enews Application
 Author :Chaithanya Krishna
 ZID:Z1815642
 IOS 521  SPRING 2018
 DUE:04-30-2018
 Instructor:Kaisone Rush
 */
//Importing the libraries required
import UIKit
//the purpose of this class is it acts as table view controller for the entertainment
class EntertainmentTableViewController: UITableViewController {

    //declaring the object
    var entObject = [Article]()
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        //setting height of each row
        self.tableView.rowHeight = 200
        navigationItem.title = "Breaking News"
        //calling the lkoad JSOn method
        loadJSON()
        
        
    }
    //Implementing the function for formatting the data
    func dataFormat(value: AnyObject?) -> String? {
        if value is NSNull {
            return "NULL"
        }
        if value! is NSNumber {
            return value?.stringValue
        }
        return (value as! String)
    }
    //implementing the JSON function
    func loadJSON() {
        
        guard let api_url = URL(string:"https://newsapi.org/v2/top-headlines?country=us&category=entertainment&apiKey=b1091b5dd2f54a50bc2bd076eb4469fd")
            else {return}
        // Create a URL request with the API address
        let urlRequest = URLRequest(url: api_url)
        // Submit a request to get the JSON data
        let task = URLSession.shared.dataTask(with:
        urlRequest) { (data,response,error) in
            // If there is an error, print the error and do not continue
            if error != nil {
                print(error!)
                return
            } // end if
            // If there is no error, fetch the json formatted content
            if let content = data {
                do {
                    let jsonObject = try
                        JSONSerialization.jsonObject(with: content, options:
                            JSONSerialization.ReadingOptions.mutableContainers) as
                    AnyObject
                    // Fetch only the articles
                    if let articlesJson =
                        jsonObject["articles"] as? [[String:AnyObject]] {
                        //print("Count of artiucles JSON is ",articlesJson.count)
                        for eachArticle in articlesJson {
                            let a_id = self.dataFormat(value : eachArticle["source"]?["id"] as AnyObject)!
                            let a_name = self.dataFormat(value : eachArticle["source"]?["name"] as AnyObject)!
                            let a_title = self.dataFormat(value: eachArticle["title"])!
                            let a_author = self.dataFormat(value: eachArticle["author"])!
                            let a_desc = self.dataFormat(value: eachArticle["description"])!
                            let a_url = self.dataFormat(value: eachArticle["url"])!
                            let a_urlToImage = self.dataFormat(value :eachArticle["urlToImage"])!
                            let a_publishedAt = self.dataFormat(value : eachArticle["publishedAt"])!
                            //add each article object to array of objects created above
                            self.entObject.append(Article(id : a_id,name : a_name,author : a_author, title : a_title,desc : a_desc,url : a_url,urlToimage : a_urlToImage,publishedAt : a_publishedAt))
                            DispatchQueue.main.async{   self.tableView.reloadData() }
                        }
                       
                    } //end the outer "if" statement
                } // end the "do" loop
                catch { print(error) }
            } // end if
        } // end getDataSession
        task.resume()
        //print("Article object count is ",articleObject.count);
    } // end readJasonData function
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        
        return entObject.count
    }
    
    //setting the data into each cell
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let article:Article = entObject[indexPath.row]
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ENTCELL", for: indexPath) as! EntTableViewCell
        
        //Geting the image based on the URL given Above
        if(article.urlToimage != "NULL")
        {
        if let url = URL(string: article.urlToimage!){
            do{
                let x = try Data(contentsOf: url)
                cell.entImage.image = UIImage(data:x);
            }
            catch let ImageError {
                print("Unable to read image in cell")
            }
        }
        }
        else
        {
            cell.entImage.image = UIImage(named : "sample.jpg")
        }
        //Set the image ,name of each article
        cell.entTitle.text = article.title
        cell.entSource.text = article.name
        cell.entPublish.text = article.publishedAt
        
        //Return the cell
        return cell
    }
    //prepare seque for the Detail view controller
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // First identify the DetailViewController as the destination view controller
        if (segue.identifier == "edv") {
            let destVC = segue.destination as! ETDetailViewController
            
            // set the variables in the detail view controller
            // DetailViewController
            if let indexPath = self.tableView.indexPathForSelectedRow {
                let article:Article = entObject[indexPath.row]
                
                destVC.entauthor = article.author
                destVC.entdesc = article.desc
                destVC.enttitle = article.title
                destVC.entimage = article.urlToimage
                destVC.entwebsite = article.url
                destVC.enthead = article.name
            } // end if
        } // end if
    }
    

}
