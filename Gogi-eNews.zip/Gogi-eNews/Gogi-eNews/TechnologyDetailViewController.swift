//
//  TechnologyDetailViewController.swift
//  Gogi-eNews
//
//  Created by Chaithanya Krishna Gogineni on 4/30/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
/*
 This is IOS 521 Assignment 7
 name : enews Application
 Author :Chaithanya Krishna
 ZID:Z1815642
 IOS 521  SPRING 2018
 DUE:04-30-2018
 Instructor:Kaisone Rush
 */
//Importing the libraries required
import UIKit

//The purpose of this class is it acts as view controlelr for technology detail view
class TechnologyDetailViewController: UIViewController {

    //referencing the outlets required
    @IBOutlet weak var techDetailDesc: UILabel!
    @IBOutlet weak var techDetailTitle: UILabel!
    @IBOutlet weak var techDetailAuthor: UILabel!
    @IBOutlet weak var techDetailImage: UIImageView!
    
    //declaring the variables required
    var techtitle : String!
    var techauthor : String!
    var techdesc : String!
    var techimage : String!
    var techwebsite : String!
    var techhead : String!
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = techhead
        //initilaising the variables required
        self.techDetailAuthor.text = techauthor
        self.techDetailDesc.text = techdesc
        self.techDetailTitle.text = techtitle
        if let url = URL(string: techimage!){
            do{
                let x = try Data(contentsOf: url)
                self.techDetailImage.image = UIImage(data:x);
            }
            catch let ImageError {
                print("Unable to read image")
            }
        }
        // Do any additional setup after loading the view.
        // Do any additional setup after loading the view.
    }
    //implementing the segue for the website 
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        //if the segue identifier is www,then navigate to other screen(website screen)
        if (segue.identifier == "twww") {
            let destVC = segue.destination as! TechWebsiteViewController
            //setting the title
            destVC.navigationItem.title = "Website"
            destVC.dtvTechSite = techwebsite
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
