//
//  AuthorViewController.swift
//  GogiWelcome
//
//  Created by Chaithanya Krishna Gogineni on 1/30/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//

//Importing Libraries
import UIKit
import WebKit

class AuthorViewController: UIViewController {

    //creating and referencing the outlet for webkitview
    @IBOutlet weak var myWebView: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Setting the title for View
navigationItem.title = "Chaitu Gogineni"
        /* Create a path to fetch the content/data of the index.html file located in
         the project app bundle. */
        let path = Bundle.main.path(forResource: "html/index", ofType: "html")!
        let data: Data = try! Data(contentsOf: URL(fileURLWithPath: path))
        let html = NSString(data: data, encoding:String.Encoding.utf8.rawValue)
        // Load the content of the index.html file onto the webView
        myWebView.loadHTMLString(html! as String, baseURL: Bundle.main.bundleURL)        //Do any additional setup after loading the view.
    }

    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
