//
//  ViewController.swift
//  GogiWelcome
//
//  Created by Chaithanya Krishna Gogineni on 1/18/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//

//Importing the library
import UIKit

class ViewController: UIViewController {
    
   
    //Creating and referencing outlets for image and label
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var displayLabel: UILabel!
    
    //creating Action for buttons
    @IBAction func buttonTouch(_ sender: UIButton) {
        // Check to see if the current title of the button is "CSCI321."
        if (sender.currentTitle == "CSCI321") {
            // Display a welcome message on the console.
            print ("Welcome iOS UNDERGRADUATE students 👋 👋 👋 ") // Display a welcome message in the lable on the view.
            displayLabel.text = "Welcome iOS UNDERGRADUATE students 👋 👋 👋 " //Display undergraduate group photo.
            imageView.image = UIImage(named: "ustudents.jpg")
        }
            // Check to see if the current title of the button is "CSCI321."
        else if (sender.currentTitle! == "CSCI521") {
            // Display a welcome message on the console.
            print ("Welcome iOS GRADUATE students 👏 👏 👏 ") // Display a welcome message on the console.
            
            displayLabel.text = "Welcome iOS GRADUATE students 👏 👏 👏 "
            // Display graduate group photo.
            imageView.image = UIImage(named: "gstudents.jpg")
        }    }
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    

}

