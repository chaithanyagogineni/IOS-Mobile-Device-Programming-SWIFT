//
//  AboutAppViewController.swift
//  Gogi_EmpDirectory
//
//  Created by Chaithanya Krishna Gogineni on 4/13/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
/*
 This is IOS 521 Student Project  Application
 Author :Chaithanya Krishna
 ZID:Z1815642
 MID TERM
 IOS 521  SPRING 2018
 DUE:04-16-2018
 Instructor:Kaisone Rush
 */
//Importing the libraries required
import UIKit
import MessageUI

//This class acts as a controller for About App Screen
class AboutAppViewController: UIViewController ,MFMailComposeViewControllerDelegate {
   
//Referencing the IBAction of Done button
    @IBAction func doneButton(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    //Referencing the IBAction of about author button
    @IBAction func aboutAuthor(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let destinationVC = storyboard.instantiateViewController(withIdentifier: "AuthorViewController") as! AuthorViewController
        self.navigationController?.pushViewController(destinationVC, animated: true)
        
    }
    //Implementing the view Did load method
    override func viewDidLoad() {
        super.viewDidLoad()
  navigationItem.title = "About App"
        // Do any additional setup after loading the view.
    }

    //Implementing the App Feedback button
    @IBAction func appFeedback(_ sender: Any) {
        
        //Initialising the variables
        
        let mailComposeVC = MFMailComposeViewController()
        
        mailComposeVC.mailComposeDelegate = self
        
        //setting the variables
        let toRecipients = ["niucsci@gmail.com"]
        let emailTitle = " App Feedback"
        let messageBody = "Sample Text"
        
        //Calling the functions that helps to send the required receipents
        mailComposeVC.setToRecipients(toRecipients)
        //Function that helps to set the title of the email
        mailComposeVC.setSubject(emailTitle)
        //Setting the Mesage Body
        mailComposeVC.setMessageBody(messageBody, isHTML: false)
        
        self.present(mailComposeVC, animated: true, completion: nil)
    }
    // This function displays the message string on the console
    // so that I can test to make sure if the email message was
    // cancelled, failed, saved draft or sent.
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        
        switch result.rawValue {
            
        case MFMailComposeResult.cancelled.rawValue:
            print("cancelled")
            
        case MFMailComposeResult.failed.rawValue:
            print("failed")
            
        case MFMailComposeResult.saved.rawValue:
            print("saved")
            
        case MFMailComposeResult.sent.rawValue:
            print("sent")
            
        default:
            break
            
        }
        
        // Dismiss the compose view controller after the ComposeVC
        // finishes.
        self.dismiss(animated: true, completion: nil)
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


}
