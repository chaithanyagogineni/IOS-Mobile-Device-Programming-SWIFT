//
//  EmpDetailViewController.swift
//  Gogi_EmpDirectory
//
//  Created by Chaithanya Krishna Gogineni on 4/12/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
/*
 This is IOS 521 Student Project  Application
 Author :Chaithanya Krishna
 ZID:Z1815642
 MID TERM
 IOS 521  SPRING 2018
 DUE:04-16-2018
 Instructor:Kaisone Rush
 */
//Importing the libraries required
import UIKit
import MessageUI

//this class acts as controller for detail view .
//Add MFMailComposeViewControllerDelegate as header to the class
class EmpDetailViewController: UIViewController ,MFMailComposeViewControllerDelegate {

    
    //Referencing the outlets in the detail view for each label
    @IBOutlet weak var empGender: UILabel!
    @IBOutlet weak var empDob: UILabel!
    @IBOutlet weak var empImage: UIImageView!
    @IBOutlet weak var empPostcode: UILabel!
    @IBOutlet weak var empState: UILabel!
    @IBOutlet weak var empStreet: UILabel!
   
  
    
    @IBOutlet weak var empEmail: UILabel!
    @IBOutlet weak var empCell: UILabel!
    @IBOutlet weak var empPhone: UILabel!
    @IBOutlet weak var empRegistered: UILabel!
    @IBOutlet weak var empCity: UILabel!
    
    
    //Declaring the variables that are required to set the data in the detail view controller
    var tvempImage : String!
    var tvempUsername: String!
    var tvempPassword : String!
    var tvempDob : String!
    var tvempPostcode : String!
    var tvempState : String!
    var tvempStreet : String!
    var tvempEmail : String!
    var tvempCell : String!
    var tvempPhone : String!
    var tvempRegistered : String!
    var tvempCity : String!
    var tvempName : String!
    var tvempLastName : String!
    var tvempGender : String!
    var tvemptitle : String!
   
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //Adding the Navigation Bar Info Button
        addRightNavigationBarInfoButton()
        //Setting the title of screen as the name of employee
        navigationItem.title = tvemptitle+" "+tvempName+" "+tvempLastName
        //Converting the image based on the URL given
        if let url = URL(string: tvempImage!){
            do{
                let x = try Data(contentsOf: url)
                self.empImage.image = UIImage(data:x);
            }
            catch let ImageError {
                print("Unable to read image")
            }
        }
        //Setting the variables of the detail view controller
        self.empGender.text = tvempGender
      
        self.empStreet.text = tvempStreet
        self.empCity.text = tvempCity
        self.empState.text = tvempState
        self.empPostcode.text = tvempPostcode
        self.empDob.text = tvempDob
        self.empRegistered.text = tvempRegistered
        self.empPhone.text = tvempPhone
        self.empCell.text = tvempCell
        self.empEmail.text = tvempEmail
       
        // Do any additional setup after loading the view.
    }
    //implementing function to add navigation button
    func addRightNavigationBarInfoButton() {
        
        // Create an Info Light button
        let button = UIButton(type: .infoDark)
        button.addTarget(self, action: #selector(self.showAboutAppView), for: .touchUpInside)
        
        // Place the button at the top right corner of the navigation bar
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(customView: button)
    }
    
   //referencing the IBAction for the Call Button
    @IBAction func cellCall(_ sender: UIButton) {
        let myURL:NSURL = URL(string :"tel//\(self.empCell.text!)")! as NSURL
        UIApplication.shared.open(myURL as URL, options: [:], completionHandler: nil)
    }
    //referencing the IBAction for the Phone Button
    @IBAction func phoneCall(_ sender: Any) {
        let myURL:NSURL = URL(string :"tel//\(self.empPhone.text!)")! as NSURL
        UIApplication.shared.open(myURL as URL, options: [:], completionHandler: nil)
    }
   //Referencing the Email Click Button
    @IBAction func emailClick(_ sender: Any) {
        
        //Initialising the variables
        
        let mailComposeVC = MFMailComposeViewController()
        
        mailComposeVC.mailComposeDelegate = self
        
        //setting the variables
        let toRecipients = [empEmail.text!]
        let emailTitle = "subject"
        let messageBody = "Sample text"
        
        //Calling the functions that helps to send the required receipents
        mailComposeVC.setToRecipients(toRecipients)
        //Function that helps to set the title of the email
        mailComposeVC.setSubject(emailTitle)
        //Setting the Mesage Body
        mailComposeVC.setMessageBody(messageBody, isHTML: false)
        
        self.present(mailComposeVC, animated: true, completion: nil)
    }
    //Implementing the function that helps to naviage to author view when user clicks on info button
    @objc func showAboutAppView() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "AboutAppNavigationController") as! UINavigationController
        self.present(controller, animated: true, completion: nil)
        
    }
    //Implementing the mailComposeController
    // This function displays the message string on the console
    // so that I can test to make sure if the email message was
    // cancelled, failed, saved draft or sent.
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        
        switch result.rawValue {
            
        case MFMailComposeResult.cancelled.rawValue:
            print("cancelled")
            
        case MFMailComposeResult.failed.rawValue:
            print("failed")
            
        case MFMailComposeResult.saved.rawValue:
            print("saved")
            
        case MFMailComposeResult.sent.rawValue:
            print("sent")
            
        default:
            break
            
            self.dismiss(animated: true, completion: nil)
        }
    
    }
    
}
