//
//  EmpTableViewCell.swift
//  Gogi_EmpDirectory
//
//  Created by Chaithanya Krishna Gogineni on 4/12/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
/*
 This is IOS 521 Student Project  Application
 Author :Chaithanya Krishna
 ZID:Z1815642
 MID TERM
 IOS 521  SPRING 2018
 DUE:04-16-2018
 Instructor:Kaisone Rush
 */
//Importing the libraries required
import UIKit

//This class is used to set the members of a cell in the table view
class EmpTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    //referencing the Image View outlet and label outlet
    @IBOutlet weak var empImage: UIImageView!
    
    @IBOutlet weak var empName: UILabel!
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
