//
//  EmpTableViewController.swift
//  Gogi_EmpDirectory
//
//  Created by Chaithanya Krishna Gogineni on 4/11/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
/*
 This is IOS 521 Student Project  Application
 Author :Chaithanya Krishna
 ZID:Z1815642
 MID TERM
 IOS 521  SPRING 2018
 DUE:04-16-2018
 Instructor:Kaisone Rush
 */
//Importing the libraries required
import UIKit

//The purpose of this class is ,it acts as controller for Employee Table view.This displays images and names of employees.
//This also has search bar to search for employees
//Add UI search bar delegate as header to this class
class EmpTableViewController: UITableViewController , UISearchBarDelegate{
    //Declare each employee as struct and each name,location,id,picture as structures
    struct Employee: Decodable{
        let gender : String?
        let name : Name
        let location : Location
        let email : String?
        let login : Login
        let dob : String?
        let registered : String?
        let phone : String?
        let cell : String?
        let id : Id
        let picture : Picture
        let nat : String?
        
    }
    struct Picture : Decodable {
        let large : String?
        let medium : String?
        let thumbnail: String?
        
    }
    struct Id : Decodable {
        let name : String?
        let value : String?
    }
    struct Login : Decodable {
        let username : String?
        let password : String?
        let salt : String?
        let md5 : String?
        let sha1 : String?
        let sha256 : String?
        
    }
    struct Name : Decodable {
        let title: String?
        let first : String?
        let last : String?
    }
    struct Location : Decodable {
        let street : String?
        let city : String?
        let state : String?
        let postcode : String?
       
    }
    
    //Referencing the search bar outlet
    @IBOutlet weak var searchField: UISearchBar!
    
    //Declaring the Employee object for the structure created above
    var empObject = [Employee]()
    //Creating temporary object to store the employees based on search
    var tempEmpobject = [Employee]()
    //Implementing the function viewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        //Setting the table view height
self.tableView.rowHeight = 150
        //Calling the function loadJSON
        loadJSON()
        //Setting the search field delegate to self
        searchField.delegate = self
    }
    //Implementing the function loadJSOn.This function helps to read data from the JSON file and pass it to structures created above for employees
    func loadJSON() {
        
        //Reading the URL of JSON data
        guard let jsonURL = URL(string: "http://faculty.cs.niu.edu/~krush/ios/empDirectory-json")
            else {return}
        let urlRequest = URLRequest(url: jsonURL)
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            if error != nil {
                print(error!)
                return
            }
            if let responseData = data{
                
                do{
                    //Serialising the JSON object
                    let jsonObject = try JSONSerialization.jsonObject(with: responseData, options: JSONSerialization.ReadingOptions.mutableContainers) as AnyObject
                    if let employeeJSON = jsonObject as? [[String: AnyObject]]{
                        
                        // now putting different employee JSON object into Swift Employee object
                        for eachEmp in employeeJSON{
                            //Calling appropriate constructors for each structure
                           
                            let name = Name(title : eachEmp["name"]!["title"]!! as! String , first : eachEmp["name"]!["first"]!! as! String,last : eachEmp["name"]!["last"]!! as! String);
                            let location = Location(street : eachEmp["location"]!["street"]!! as! String, city : eachEmp["location"]!["city"]!! as! String, state : eachEmp["location"]!["state"]!! as! String, postcode : (eachEmp["location"]!["postcode"]!! as AnyObject).stringValue);
                           
                            let login = Login(username: eachEmp["login"]!["username"]!! as! String, password : eachEmp["login"]!["password"]!! as! String, salt : eachEmp["login"]!["salt"]!! as! String, md5 : eachEmp["login"]!["md5"]!! as! String, sha1 : eachEmp["login"]!["sha1"]!! as! String,sha256 : eachEmp["login"]!["sha256"]!! as! String);
                            
                            let id = Id(name : eachEmp["id"]!["name"]!! as! String,value : (eachEmp["id"]!["value"]!! as AnyObject).stringValue);
                            let picture = Picture(large : eachEmp["picture"]!["large"]!! as! String, medium : eachEmp["picture"]!["medium"]!! as! String, thumbnail : eachEmp["picture"]!["thumbnail"]!! as! String);
                            
                            //Calling the employee structure
                            let e = Employee(gender :  eachEmp["gender"]! as! String,name : name, location : location ,email : eachEmp["email"]! as! String, login : login ,dob : eachEmp["dob"]! as! String, registered : eachEmp["registered"]! as! String, phone : eachEmp["phone"]! as! String, cell : eachEmp["cell"]! as! String, id : id, picture : picture , nat : eachEmp["nat"]! as! String);
                            //Appending the reference created above into employee object created above
                            
                            self.empObject.append(e);
                            //Record that current object into the temporary object created above
                            self.tempEmpobject = self.empObject
                        }
                        //print(self.empObject.count);
                        // to make sure that the table data gets populated once the JSON data is decoded
                        DispatchQueue.main.async{   self.tableView.reloadData() }
                        
                    } else {
                        let error = "Could not create an Employee object from the JSON "
                        print (error)
                    }
                } catch {
                    print("Check the JSON that is being read")
                    return
                }
            }
        }
        task.resume()
    }

    //implementing the function didRecieveWarning
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    //Num of sections in the table view
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1;
    }

    //Number of rows in the table view
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return tempEmpobject.count
    }

    //This function sets the data for each cell.
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //Creating employee object of type Employee and get the details of that employee based on row
        let employee:Employee = tempEmpobject[indexPath.row]
        
        //Identify the cell with identifier as CELL and set that details from the object fetched above
        let cell = tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath) as! EmpTableViewCell
        
        //Geting the image based on the URL given Above
        if let url = URL(string: employee.picture.medium!){
            do{
                let x = try Data(contentsOf: url)
                cell.empImage.image = UIImage(data:x);
            }
            catch let ImageError {
                print("Unable to read image")
            }
        }
        //Set the image ,name of each employee
        cell.empName.text = (employee.name.title!+"."+employee.name.first!+" "+employee.name.last!)
       
       //Return the cell
        return cell
    }
    
    //Setting the varibale of the destination view controller
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // First identify the DetailViewController as the destination view controller
        if (segue.identifier == "DETAIL") {
            let destVC = segue.destination as! EmpDetailViewController
            
            //Set the values in the detail view controller
            if let indexPath = self.tableView.indexPathForSelectedRow {
                let employee:Employee = tempEmpobject[indexPath.row]
                destVC.tvempImage = employee.picture.large
                destVC.tvempDob = employee.dob
                destVC.tvempPostcode = employee.location.postcode
                destVC.tvempState = employee.location.state
               destVC.tvempStreet = employee.location.street
                destVC.tvempEmail = employee.email
               destVC.tvempCell = employee.cell
               destVC.tvempPhone = employee.phone
                destVC.tvempRegistered  = employee.registered
               destVC.tvempCity = employee.location.city
                destVC.tvempLastName = employee.name.last
                destVC.tvempName  = employee.name.first
                destVC.tvempGender = employee.gender
                destVC.tvemptitle = employee.name.title
             
            } // end if
        } // end if
    }
    
    //Implementing the search bar functionality
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        guard !searchText.isEmpty else {
            tempEmpobject = empObject
            tableView.reloadData()
            return
    }
        //Search the text we entered by converting it to lower case
        tempEmpobject = empObject.filter({Employee -> Bool in
            guard let x = searchField.text?.lowercased() else { return false }
            //get the full name of employee into the variable and search for it
            let k = Employee.name.title!+"."+Employee.name.first!+" "+Employee.name.last!
            return (k.lowercased().contains(x))
        })
        //Reload the data of the table view
        tableView.reloadData()
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        self.searchField.endEditing(true)
    }
    
  
}

