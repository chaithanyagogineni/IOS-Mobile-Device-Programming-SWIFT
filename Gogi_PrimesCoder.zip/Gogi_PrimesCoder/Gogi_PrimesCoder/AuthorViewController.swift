//
//  AuthorViewController.swift
//  Gogi_PrimesCoder
//This is author view controller.this acts as controller for author view screen.
//This sets the path for the author page and link that with css file
//  Created by Chaithanya Krishna Gogineni on 2/13/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//

//Importing the headers required
import UIKit
import WebKit
class AuthorViewController: UIViewController {
//referencing the webkit view
   
    @IBOutlet weak var authorView: WKWebView!

//implementing the viewDidLoad().This function takes no parameters.
    override func viewDidLoad() {
//Calling the super class method .
        super.viewDidLoad()

        //Setting the title for View
        navigationItem.title = "Chaitu Gogineni"
        /* Create a path to fetch the content/data of the index.html file located in
         the project app bundle. */
        let path = Bundle.main.path(forResource: "html/index", ofType: "html")!
        let data: Data = try! Data(contentsOf: URL(fileURLWithPath: path))
        let html = NSString(data: data, encoding:String.Encoding.utf8.rawValue)
        // Load the content of the index.html file onto the webView
        authorView.loadHTMLString(html! as String, baseURL: Bundle.main.bundleURL)        //Do any additional setup after loading the view.
        // Do any additional setup after loading the view.
    }
}
