//This is ViewController.swift file.
//  ViewController.swift
//  Gogi_PrimesCoder
//This is the controller for the 1st view which we see on the app.This basically implements the logic for calculating the prime numbers
//  Created by Chaithanya Krishna Gogineni on 2/12/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//Importing the header files required.

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var TextValue: UITextField!
   
//Implementing clear function.setting the text to empty.This function clear the text and sets it to empty.
    @IBAction func clear(_ sender: UIButton) {
        textView.text=""
        TextValue.text=""
    }
    
//Reference the text view
    @IBOutlet weak var textView: UITextView!
//Implementing the button find primes.This function performs appropriate task based on value entered by user.
    @IBAction func ButtonClick(_ sender: UIButton) {
        TextValue.resignFirstResponder()
//getting the value entered in the text field into the variable
        let InputNum=Int(TextValue.text!)
//If input value is less than or equal to 25.Show error message
        if(InputNum!<=25)
        {
//Calling the display alert method
            displaySimpleAlert();
        }
//if input value greater than 25 then call calculate primes function
        else{
            calculatePrimes(InputNum:InputNum!)
        }
    }
//implementing the calculatePrimes function.This function takes one integer argument.
    //This function calculates the prime numbers until the given integer
    func calculatePrimes(InputNum:Int)
    {
//initialsing the array with size as number entered in the text field
        var result = Array(repeating: true, count: InputNum+1)
//Initialsing a constant variable with the number entered in the text field
        let num=InputNum
//Calculating the square root of the number entered and store it in variable
        var sqrt_num=Int(sqrt(Double(num)))
//logic to finf the primes
        for i in 4...num
        {
            sqrt_num=(Int)(sqrt(Double(i)))
            for j in 2...sqrt_num
            {
                //If number is not prime .Make that false
            if(i%j==0)
            {
                result[i]=false;
                
            }
            }
        }
//Declare new array
            var arr = Array<Int>()
//Loop over the array and find if it is true.
            for i in 2...InputNum
            {
                //if it is true.Then its a prime number.Add it to result array
                if(result[i]==true)
                {
                    arr.append(i);
                 }
            }
//After computing the primes.Display the count of primes followed by the List of primes.
        textView.text="Number of primes found \(arr.count) \n\n"
//Describing the primes until given number
        textView.text.append(String(describing : arr))
        
    }
//implementing the fucntion displaySimpleAlert().This takes no parameters.Displays error message
    func displaySimpleAlert()
    {
        textView.text="Please enter a number greater than or equal to 25"
    }
    
//implementing the viewDidLoad function.this function takes no parameters.
    override func viewDidLoad() {
//Calling the super class method
        super.viewDidLoad()
//Calling the configureSpecificKBTextField
        configureSpecificKBTextField()        // Do any additional setup after loading the view, typically from a nib.
        
    }
    //Implementing configureSpecificKBTextField function.This takes no parameters.
    func configureSpecificKBTextField() {
//Putting the placeholder in the text field.
        TextValue.placeholder = NSLocalizedString("Enter", comment: "")
//Setting the keyboard type to NUMBER pad.
        TextValue.keyboardType = .numberPad
        TextValue.returnKeyType = .done
    }
    
    //Function that is used to dismiss keyboard when touched outside
    
      func textFieldShouldReturn(_ textField: UITextField) -> Bool {
                TextValue.resignFirstResponder()
        
                return true
            }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
}
//Extensions for disabling the keyboard
//If user hits anywhere on the screen after clearijng result.he will not be able to see keyboard
extension UIViewController {
    func hideKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
    }
    //
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
}
    


