//: Playground - noun: a place where people can play

//part1 of assignment
//Author :Chaithanya Krishna G.
//This is the swift code used to find all the prime numbers that are less than the given number.

//Import header files required
import UIKit
//Initialise a number
var InputNum=35
//Declare an array with all trues
if(InputNum>=25)
{
var result = Array(repeating: true, count: InputNum+1)
//Copy the number into a input variable
let num=InputNum
//calculating the square root of given number
var sqrt_num=Int(sqrt(Double(num)))
//compute the prime number until the given number
for i in 4...num
{
    sqrt_num=(Int)(sqrt(Double(i)))
    for j in 2...sqrt_num
    {
        //If number is not prime,then set the array value as false
        if(i%j==0)
        {
            result[i]=false;
            
        }
    }
}
//take an empty array
var arr = Array<Int>()


//For all the numbers that has true value.Print its index which is the prime number
for i in 2...InputNum
{
    if(result[i]==true)
    {
        arr.append(i);
        print(i)
    }
}
    //Print the count of result array which has primes
    print("The number of primes found are",arr.count)
}
    
    //If number is less than 25,print an error message
else
{
    print("please enter a number greater than or equal to 25")
}



