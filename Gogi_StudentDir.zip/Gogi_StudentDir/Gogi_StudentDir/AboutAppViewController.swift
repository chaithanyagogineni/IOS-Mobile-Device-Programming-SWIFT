//
//  AboutAppViewController.swift
//  Gogi_StudentDir
//
//  Created by Chaithanya Krishna Gogineni on 3/29/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
/*
 Author:Chaithanya Krishna
 Spring 2018
 IOS 321/521
 Assignment 6
 Instructor:Kaisone Rush
 TA:Daniel Baker
 */
//importing header files required
import UIKit
//The purpose of this file is this acts as controller for About App view
class AboutAppViewController: UIViewController {

    //Impleemnting the IBAction for the done button 
    @IBAction func doneButton(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    // This function navigate to the "About Author" view when
    // the "About Author" button is pressed.
    @IBAction func aboutAuthorButton(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let destinationVC = storyboard.instantiateViewController(withIdentifier: "AuthorViewController") as! AboutAuthorViewController
        self.navigationController?.pushViewController(destinationVC, animated: true)
        
    }
    //implementing the viewdidload method
    override func viewDidLoad() {
        super.viewDidLoad()
        //setting the title of the view
        navigationItem.title = "About App"
        
        // Do any additional setup after loading the view.
    }
    
    
    
    

}
