//
//  StudentDetailViewController.swift
//  Gogi_StudentDir
//
//  Created by Chaithanya Krishna Gogineni on 3/29/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
/*
 Author:Chaithanya Krishna
 Spring 2018
 IOS 321/521
 Assignment 6
 Instructor:Kaisone Rush
 TA:Daniel Baker
 */
//importing header files required
import UIKit
//This class acts as view controller for Deyail view.
//This class helps to display all the details of selected student from the table view
class StudentDetailViewController: UIViewController {

    //Referencing IBoutlets for image and labels
    @IBOutlet weak var studentImage: UIImageView!
    
    @IBOutlet weak var studentTitle: UILabel!
    
    @IBOutlet weak var studentTerm: UILabel!
    
    @IBOutlet weak var studentPhone: UILabel!
    
    @IBOutlet weak var studentEmail: UILabel!
    
    @IBOutlet weak var studentCourse: UILabel!
    
    //declaring the variables required for initilaising the image and labels created above
    var tvstudentImage:String!
    var tvstudentTitle:String!
    var tvstudentTerm:String!
    var tvstudentPhone:String!
    var tvstudentEmail:String!
    var tvstudentCourse:String!
    var tvstudentfn:String!
    var tvstudentln:String!

    //Implementing the function view did load
    override func viewDidLoad() {
        super.viewDidLoad()
        //calling the method to add info light button at the top
        addRightNavigationBarInfoButton()
        //Setting the title as student name
navigationItem.title = tvstudentfn+" "+tvstudentln
        //casting the image from the string URL
        if let url = URL(string: tvstudentImage!){
            do{
                let x = try Data(contentsOf: url)
                self.studentImage.image = UIImage(data:x);
            }
            catch let ImageError {
                print("Unable to read image")
            }
        }
        //setting the labels from teh variabels of detail view controller
        studentTitle.text = tvstudentTitle
        studentTerm.text = tvstudentTerm
        studentPhone.text = tvstudentPhone
        studentEmail.text = tvstudentEmail
        studentCourse.text = tvstudentCourse
        // Do any additional setup after loading the view.
    }
    //implementing function to add navigation button
    func addRightNavigationBarInfoButton() {
        
        // Create an Info Light button
        let button = UIButton(type: .infoDark)
        button.addTarget(self, action: #selector(self.showAboutAppView), for: .touchUpInside)
        
        // Place the button at the top right corner of the navigation bar
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(customView: button)
    }
    //This function helps to connect to navigation controller up on clicking Info light button
    @objc func showAboutAppView() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "AboutAppNavigationController") as! UINavigationController
        self.present(controller, animated: true, completion: nil)
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
