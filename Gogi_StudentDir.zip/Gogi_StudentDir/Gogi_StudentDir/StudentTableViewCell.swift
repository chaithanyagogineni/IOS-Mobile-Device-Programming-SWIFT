//
//  StudentTableViewCell.swift
//  Gogi_StudentDir
//
//  Created by Chaithanya Krishna Gogineni on 3/27/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
/*
 Author:Chaithanya Krishna
 Spring 2018
 IOS 321/521
 Assignment 6
 Instructor:Kaisone Rush
 TA:Daniel Baker
 */
//importing header files required
import UIKit
//This class has all UI elements that helps to display on the table view.
//This class helps as table view cell
class StudentTableViewCell: UITableViewCell {

    //referencing the IBoutlets for Image and labels
    @IBOutlet weak var studentImage: UIImageView!
    
    @IBOutlet weak var courseYear: UILabel!
    
    @IBOutlet weak var lastName: UILabel!
    @IBOutlet weak var firstName: UILabel!
    
    //Overiding the function awakeFromNib
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    //Implementing the function setSelected
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
