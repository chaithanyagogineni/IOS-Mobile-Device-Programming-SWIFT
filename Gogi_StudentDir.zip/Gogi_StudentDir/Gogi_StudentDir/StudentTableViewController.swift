//
//  StudentTableViewController.swift
//  Gogi_StudentDir
//
//  Created by Chaithanya Krishna Gogineni on 3/27/18.
//  Copyright © 2018 Chaithanya Krishna Gogineni. All rights reserved.
//
/*
 Author:Chaithanya Krishna
 Spring 2018
 IOS 321/521
 Assignment 6
 Instructor:Kaisone Rush
 TA:Daniel Baker
 */
//importing header files required
import UIKit
//This class purpose is to read data from the JSOn file and display in the table view.This is controller for table view
class StudentTableViewController: UITableViewController  {
    // Use Apple's Decodable protocol for reading json data into this data structure.
    // Note that the name of each attribute of the Student object must spell exactly the
    // same as the corresponding attribute name in the external json object file.
    //This is the structure used to store each student data
    struct Student: Decodable {
        let id:Int?
        let firstName:String?
        let lastName:String?
        let title:String?
        let phone:String?
        let email:String?
        let course:String?
        let term:String?
        let year:Int?
        let imageURL:String?
    }
    //Student object that helps to store instances of each student.create an array of that
    var studentObject = [Student]()
    //Implementing the function view did load
    override func viewDidLoad() {
        super.viewDidLoad()
        //Setting the table view height
        self.tableView.rowHeight = 150
        //Loading the JSON file
        loadJSON()
        
    }

    // This function makes a request to load json file from the indicated URL.
    // And display the output on the console.
    //This function helps to read data from the JSON file
    func loadJSON() {
        //set the path of JSOn file
        let jsonURL = "http://faculty.cs.niu.edu/~krush/ios/rushStudents-json"
        //getting the url into string
        guard let url = URL(string: jsonURL) else
        { return }
        URLSession.shared.dataTask(with: url) { (data,
            response, err) in
            guard let jsonData = data else { return }
            // To view data as string before parsing.
            //let stringData = String(data: jsonData,encoding: .utf8)
            //print(stringData)
            do {
                //get the JSON data into students
                let students = try
                    JSONDecoder().decode([Student].self, from: jsonData)
               
                // To view “students"after parsing/decoding
                //For each student add that student to studentObject array created above
                for eachStudent in students {
                    
                  //call the constructor of each student
                    let s = Student(id: eachStudent.id!,firstName: eachStudent.firstName!,lastName: eachStudent.lastName!,title: eachStudent.title!,phone: eachStudent.phone!,email: eachStudent.email!,course: eachStudent.course!,term: eachStudent.term!,year: eachStudent.year!,imageURL: eachStudent.imageURL!)
                    self.studentObject.append(s)
                   
                }
                //to reload data into table view
                DispatchQueue.main.async{self.tableView.reloadData()}
            } catch let jsonErr {
                //prit error if we encounter any
                print ("Error Reading JSON: ", jsonErr)
            }
           // print("Student objects count is ", self.studentObject.count)
            }.resume()  //URLSession
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
    //return the number of rows on teh table view
        return self.studentObject.count
    }

    //This function sets the data for each cell.
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //read each student into each row of table view controller
        let student:Student = studentObject[indexPath.row]
        
        // Assign a table view cell with the TableViewCell class
        let cell = tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath) as! StudentTableViewCell
        
        // Place cell image, student name, year in the table cell
     
        //since we read the URL  ,need to  get the image of that URL
        if let url = URL(string: student.imageURL!){
        do{
            let x = try Data(contentsOf: url)
            cell.studentImage.image = UIImage(data:x);
        }
        catch let ImageError {
            print("Unable to read image")
        }
        }
        //Set the image ,name and year of each student
      cell.firstName.text = student.firstName as String!
    cell.lastName.text = student.lastName as String!
        cell.courseYear.text = String(describing: student.year!)
        //return the cell with the fields that are set
        return cell
    }
    
    //Setting the varibale of the destination view controller
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // First identify the DetailViewController as the destination view controller
        if (segue.identifier == "DetailView") {
            let destVC = segue.destination as! StudentDetailViewController
            
            // Prepare to send Student image, Student name and student phone,email,title,term,course
            // DetailViewController
            if let indexPath = self.tableView.indexPathForSelectedRow {
                let student:Student = studentObject[indexPath.row]
                //Get the student instance of that row and set the variables of destination view controller
                destVC.tvstudentTitle = student.title
                destVC.tvstudentTerm = student.term
                destVC.tvstudentEmail = student.email
                destVC.tvstudentPhone = student.phone
                destVC.tvstudentCourse = student.course
                destVC.tvstudentfn = student.firstName
                destVC.tvstudentln = student.lastName
                destVC.tvstudentImage = student.imageURL
            } // end if
        } // end if
    }
    
}
