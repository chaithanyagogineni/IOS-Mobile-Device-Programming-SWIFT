//
//  DetailViewController.swift
//  RushPicker_iOS11
//
//  Created by Chaithanya Krishna Gogineni on 3/22/18.
//  Copyright © 2018 Chaithanya Krishna. All rights reserved.
//

/*
 This is IOS 521 Assignment 5
 Author :Chaithanya Krishna
 ZID:Z1815642
 MID TERM
 IOS 521  SPRING 2018
 DUE:03-22-2018
 Instructor:Kaisone Rush
 */
/***********Question :What happens if we do not let the picker view be its own delegate?
 Basically , delegate is used for Communication.If we put delegate as self then we are asking system to send messages to itself.So the picker view here is communicating with itself in the detail view controller
 if we dont put the delegate as self ,Then system has ambiguity in communication.It does not know where to send messages.
 **************/


//The purpose of this file is to display the information of selected cell like publisher name and ISBN of book and allow user to select an option to  buy book
//This file makes use of picker view
//Importing the libraries required
import UIKit

//Addding the headers for Picker view to Detail View Controller
class DetailViewController: UIViewController, UIPickerViewDataSource , UIPickerViewDelegate{
    
    
    //Referencing the UIImage View outlet

    @IBOutlet weak var imageView: UIImageView!
    
    //Referencing the UILabel Outlet
    @IBOutlet weak var bookTitle: UILabel!
    
    //Referencing the UILabel Outlet
    @IBOutlet weak var isbn: UILabel!
    
    ////Referencing the UIButton Outlet
    @IBOutlet weak var buttonOutlet: UIButton!
    
    ////Referencing the UIButton Action
    @IBAction func buttonAction(_ sender: Any) {
        //Make the picker view appear when user clicks on button only if picker view is not visible
        if pickerOutlet.isHidden
        {
        pickerOutlet.isHidden = false
        }
    }
    //Referencing the PickerView Outlet
    @IBOutlet weak var pickerOutlet: UIPickerView!
    
    //Creating the varibales required for storing publisher,isbn and image of book
    var tvISBN : String!
    var tvBookPublisher : String!
    var tvBookImage : String!
    var tvBookAuthor : String!
    
    //Creating the array for the picker view options
    var buyOptions: [String] = ["Buy New","Buy Used","Rent"]
    
    //This function tells the delegate that there is one column in the picker view
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    //This function tells the delegate that picker view has number of rows as elemnts in buyOptions array
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return buyOptions.count
    }
    
    //This function tells the delegate that title of each row is the element in the buyOptions array
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
    return buyOptions[row]
    }
    //This function changes the button title to selected picker view option and hides the picker view
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        buttonOutlet.setTitle(buyOptions[row], for: .normal)
        pickerOutlet.isHidden = true
    }
    
    //Implementing the view Did load method
    override func viewDidLoad() {
        super.viewDidLoad()
        //Setting the title of View as Author Name
        navigationItem.title = tvBookAuthor
        //Setting the picker view outlet delegate and datasource to self to enable picker view to communcate with detail view controller
          pickerOutlet.delegate = self
          pickerOutlet.dataSource = self
          pickerOutlet.isHidden = true
        
        //Setting the variables into the UI fields of Detail View Controller
        
        imageView.image = UIImage(named: tvBookImage)
        bookTitle.text = tvBookPublisher
        isbn.text = tvISBN
        
        

        // Do any additional setup after loading the view.
    }

    

}
